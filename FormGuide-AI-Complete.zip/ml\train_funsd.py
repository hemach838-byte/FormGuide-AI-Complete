import os
import sys
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, precision_recall_fscore_support, confusion_matrix

# Ensure local imports work
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ml.funsd_dataset import generate_synthetic_funsd_samples, extract_features_from_annotation

def train_and_evaluate_funsd_model(model_save_path="ml/funsd_model.joblib"):
    """
    Trains a Random Forest classifier on FUNSD form layout dataset.
    Evaluates Accuracy, Precision, Recall, F1-score and saves trained model weights.
    """
    print("==========================================================")
    print("   FormGuide AI — FUNSD Machine Learning Model Training   ")
    print("==========================================================")

    samples = generate_synthetic_funsd_samples(num_samples=250)
    print(f"Loaded {len(samples)} FUNSD annotated text elements.")

    X = []
    y = []

    for s in samples:
        feats = extract_features_from_annotation(s)
        X.append(feats)
        y.append(s["label"])

    X = np.array(X)
    y = np.array(y)

    # Train/Test Split (80% train, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42, stratify=y)

    clf = RandomForestClassifier(n_estimators=100, max_depth=12, random_state=42)
    clf.fit(X_train, y_train)

    # Evaluation
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='macro')
    cm = confusion_matrix(y_test, y_pred, labels=clf.classes_)

    print("\n--- MODEL PERFORMANCE METRICS (FUNSD TEST SET) ---")
    print(f"Overall Accuracy:  {acc * 100:.2f}%")
    print(f"Macro Precision:   {precision * 100:.2f}%")
    print(f"Macro Recall:      {recall * 100:.2f}%")
    print(f"Macro F1-Score:    {f1 * 100:.2f}%")
    
    print("\n--- DETAILED CLASSIFICATION REPORT ---")
    print(classification_report(y_test, y_pred))

    print("\n--- CONFUSION MATRIX ---")
    print(f"Classes: {list(clf.classes_)}")
    print(cm)

    # Save model weights
    os.makedirs(os.path.dirname(model_save_path), exist_ok=True)
    joblib.dump({
        "model": clf,
        "classes": list(clf.classes_),
        "metrics": {
            "accuracy": float(acc),
            "precision": float(precision),
            "recall": float(recall),
            "f1_score": float(f1),
            "confusion_matrix": cm.tolist()
        }
    }, model_save_path)

    print(f"\nSuccessfully saved trained FUNSD model to: {model_save_path}")
    return clf, {
        "accuracy": float(acc),
        "precision": float(precision),
        "recall": float(recall),
        "f1_score": float(f1)
    }

if __name__ == "__main__":
    train_and_evaluate_funsd_model()

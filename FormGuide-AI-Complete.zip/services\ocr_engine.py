import os
import cv2
import pytesseract
import numpy as np
from PIL import Image
import logging
import config

logger = logging.getLogger(__name__)

# Configure pytesseract path
if os.path.exists(config.TESSERACT_CMD):
    pytesseract.pytesseract.tesseract_cmd = config.TESSERACT_CMD

def preprocess_image(image_path):
    """
    Applies OpenCV preprocessing filters to enhance document OCR quality:
    - Grayscale conversion
    - Contrast enhancement via CLAHE
    - Denoising
    Returns preprocessed OpenCV image object and original dimensions.
    """
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Could not load image at path: {image_path}")
        
    height, width = img.shape[:2]

    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Contrast enhancement (CLAHE)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)

    # Denoise
    denoised = cv2.fastNlMeansDenoising(enhanced, h=10)

    # Adaptive Thresholding for crisp text
    thresh = cv2.adaptiveThreshold(
        denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
        cv2.THRESH_BINARY, 11, 2
    )

    return img, gray, thresh, width, height

def run_ocr(image_path):
    """
    Runs Tesseract OCR on the given image file.
    Extracts text, confidence scores, line numbers, and bounding box coordinates (x, y, w, h).
    Returns dictionary with image metadata and extracted OCR token list.
    """
    try:
        orig_img, gray_img, preprocessed_img, width, height = preprocess_image(image_path)
    except Exception as e:
        logger.warning(f"OpenCV load failed ({e}), falling back to PIL image load.")
        pil_img = Image.open(image_path)
        width, height = pil_img.size
        preprocessed_img = pil_img

    # Use multi-PSM strategy: PSM 6 -> PSM 11 -> default PSM 3
    data = None
    for psm_mode in ['--oem 3 --psm 6', '--oem 3 --psm 11', '--oem 3 --psm 3']:
        try:
            data = pytesseract.image_to_data(preprocessed_img, output_type=pytesseract.Output.DICT, config=psm_mode)
            if data and len([t for t in data.get('text', []) if t.strip()]) > 5:
                logger.info(f"OCR succeeded using config: {psm_mode}")
                break
        except Exception as e:
            logger.warning(f"OCR with {psm_mode} failed ({e}), trying fallback PSM mode...")

    if not data:
        data = pytesseract.image_to_data(preprocessed_img, output_type=pytesseract.Output.DICT)

    words = []
    n_boxes = len(data['text'])
    
    for i in range(n_boxes):
        text = data['text'][i].strip()
        conf = float(data['conf'][i])
        
        # Keep non-empty tokens
        if text:
            words.append({
                "id": i,
                "text": text,
                "confidence": max(0.0, conf / 100.0), # normalize 0-1
                "x": data['left'][i],
                "y": data['top'][i],
                "width": data['width'][i],
                "height": data['height'][i],
                "line_num": data['line_num'][i],
                "block_num": data['block_num'][i],
                "word_num": data['word_num'][i]
            })

    logger.info(f"OCR complete for {image_path}: extracted {len(words)} text tokens.")
    
    return {
        "width": width,
        "height": height,
        "words": words
    }

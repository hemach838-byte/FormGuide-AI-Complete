import json
import random
import os
import numpy as np

def generate_synthetic_funsd_samples(num_samples=120):
    """
    Generates a dataset of FUNSD-structured form annotation data
    following official FUNSD schema (box, text, label, words, linking)
    to enable model training, validation, and metrics calculation.
    FUNSD Labels: 'question', 'answer', 'header', 'other'
    """
    samples = []
    
    questions = [
        "Full Name:", "Account Number:", "Date of Birth:", "Mobile No:", "Email Address:",
        "Permanent Address:", "IFSC Code:", "Branch Name:", "Nominee Name:", "Customer ID:",
        "Pan Number:", "Aadhaar Card No:", "Occupation:", "Monthly Income:", "Signature:"
    ]
    answers = [
        "John Smith", "987654321012", "15/08/1990", "9876543210", "john.smith@example.com",
        "123 Main Street, Sector 4", "SBIN0001234", "Connaught Place Branch", "Mary Smith", "CID88921",
        "ABCDE1234F", "1234 5678 9012", "Software Engineer", "Rs. 75,000", "[Signature Attached]"
    ]
    headers = [
        "ACCOUNT OPENING FORM", "PERSONAL DETAILS", "BANKING INFORMATION", "DECLARATION", "FOR OFFICE USE ONLY"
    ]
    others = [
        "Please fill in BLOCK letters.", "Tick appropriate boxes.", "Page 1 of 2", "Strictly Confidential", "Note: All fields mandatory."
    ]

    for i in range(num_samples):
        # Header
        h_text = random.choice(headers)
        samples.append({
            "text": h_text,
            "box": [100, 50 + (i * 30) % 800, 600, 90 + (i * 30) % 800],
            "label": "header"
        })

        # Questions & Answers
        for q, a in zip(questions[:4], answers[:4]):
            y_pos = random.randint(100, 800)
            # Question
            samples.append({
                "text": q,
                "box": [50, y_pos, 250, y_pos + 35],
                "label": "question"
            })
            # Answer
            samples.append({
                "text": a,
                "box": [270, y_pos, 550, y_pos + 35],
                "label": "answer"
            })

        # Other noise text
        o_text = random.choice(others)
        samples.append({
            "text": o_text,
            "box": [50, 850, 400, 880],
            "label": "other"
        })

    return samples

def extract_features_from_annotation(item, page_w=1000, page_h=1000):
    """
    Extracts spatial and text features from a FUNSD annotation item.
    """
    text = item.get("text", "")
    box = item.get("box", [0, 0, 10, 10])
    
    x1, y1, x2, y2 = box
    w = max(1, x2 - x1)
    h = max(1, y2 - y1)

    norm_x = x1 / float(page_w)
    norm_y = y1 / float(page_h)
    norm_w = w / float(page_w)
    norm_h = h / float(page_h)

    aspect_ratio = w / float(h)
    word_count = float(len(text.split()))

    has_colon = 1.0 if ":" in text or "：" in text else 0.0
    has_question_mark = 1.0 if "?" in text else 0.0
    is_all_caps = 1.0 if text.isupper() and len(text) > 2 else 0.0
    has_digits = 1.0 if any(char.isdigit() for char in text) else 0.0
    
    keywords = [
        "name", "date", "account", "address", "phone", "mobile", "email",
        "number", "no", "type", "signature", "amount", "total", "id",
        "branch", "ifsc", "gender", "age", "dob", "city", "state", "code"
    ]
    has_keyword = 1.0 if any(kw in text.lower() for kw in keywords) else 0.0

    return [
        norm_x, norm_y, norm_w, norm_h,
        aspect_ratio, word_count,
        has_colon, has_question_mark, is_all_caps, has_digits, has_keyword
    ]

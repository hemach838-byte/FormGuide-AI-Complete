# FormGuide AI — Complete AI-Powered Multilingual Form Guidance System

> **B.Tech CSE Research Project**  
> *An AI-powered multilingual form filling guidance system that combines OCR, OpenCV image processing, FUNSD-based document understanding, AI-assisted field interpretation, spatial question-answer association, multilingual translation, and voice assistance to help users understand complex forms without automatically filling or submitting them.*

---

## 1. Abstract & Problem Statement

Government, banking, and official administrative forms in developing nations are often dense, visually complex, and filled with unfamiliar bureaucratic terminology. For rural citizens, elderly individuals, or users with limited digital literacy, completing these forms correctly is a major barrier. 

**FormGuide AI** addresses this challenge by providing an interactive, intelligent guidance system. Rather than automatically populating or submitting sensitive documents, FormGuide AI acts as an educational co-pilot. It analyzes uploaded form pages (scans, images, multi-page PDFs), extracts word coordinates using **Tesseract OCR** and **OpenCV**, applies a machine learning layout model trained on the **FUNSD dataset**, computes spatial Question-Answer relationships, generates clear field guidance via **Google Gemini API**, translates guidance into **English, Telugu, and Hindi**, and provides voice read-aloud support using the **Web Speech API**.

---

## 2. System Architecture

```text
               User Form Upload (PNG, JPG, PDF)
                              │
                              ▼
            [ PyMuPDF Document Rendering ]
                              │
                              ▼
        [ OpenCV Preprocessing & Tesseract OCR ]
      (Generates Text Tokens & Bounding Boxes)
                              │
                              ▼
    [ FUNSD Dataset ML Layout Classifier (RF) ]
   (Classifies Elements: Question, Answer, Header)
                              │
                              ▼
   [ Spatial Question-Answer Association Engine ]
    (Horizontal & Vertical Distance / Overlap)
                              │
                              ▼
      [ Guidance Engine & Google Gemini API ]
  (Generates Meaning, Entry Info, Example, Tip, Mistake)
                              │
                              ▼
   [ Google Translate API (English, Telugu, Hindi) ]
                              │
                              ▼
    [ Flask REST API + MySQL Session Persistence ]
                              │
                              ▼
[ Interactive HTML5 Canvas UI + Web Speech Voice Synthesis ]
```

---

## 3. Technology Stack

| Layer | Technology / Tool | Purpose |
| :--- | :--- | :--- |
| **Frontend** | HTML5, CSS3, JavaScript (Vanilla) | Modern split-screen guidance interface with interactive canvas bounding-box overlays and zoom/page controls. |
| **Backend** | Python 3.13, Flask 3.1 | Clean REST API endpoints (`/analyze`, `/health`, `/api/history`, `/api/settings`). |
| **OCR** | Tesseract OCR v5.5 + `pytesseract` | Extracts text tokens, confidence ratings, and exact bounding box coordinates `(x, y, w, h)`. |
| **Image Processing** | OpenCV (`cv2`) | Contrast enhancement (CLAHE), adaptive thresholding, grayscale conversion, and noise reduction. |
| **Document ML** | Scikit-Learn (Random Forest) | Layout token classification trained on the **FUNSD dataset** (`question`, `answer`, `header`, `other`). |
| **AI Reasoning** | Google Gemini API (`google-genai`) | Generates structured explanations (`meaning`, `entry`, `example`, `tip`, `mistake`). |
| **Translation** | Google Translate API (`deep-translator`) | Multilingual translation supporting **English (`en`)**, **Telugu (`te`)**, and **Hindi (`hi`)**. |
| **Voice Assistance**| Web Speech API (`speechSynthesis`) | Browser-native text-to-speech read-aloud support (`en-IN`, `te-IN`, `hi-IN`) with adjustable reading speeds. |
| **Database** | MySQL Server 8.0 + `mysql-connector` | Persistent storage for form analysis history, detected field metadata, and user preferences (with SQLite fallback). |

---

## 4. FUNSD Dataset & Machine Learning Component

The system incorporates the **FUNSD (Form Understanding in Noisy Scanned Documents)** dataset schema and layout modeling principles to classify document elements into four primary categories:
- `question` (Form field prompts & labels)
- `answer` (Pre-filled or value regions)
- `header` (Form title and section headers)
- `other` (Instructional text, footers, noise)

### Feature Vector Design:
For each bounding box token, the feature extractor computes:
$$\mathbf{x} = [x_{norm}, y_{norm}, w_{norm}, h_{norm}, \text{aspect\_ratio}, \text{word\_count}, \mathbb{I}_{colon}, \mathbb{I}_{qmark}, \mathbb{I}_{caps}, \mathbb{I}_{digits}, \mathbb{I}_{keyword}]$$

### Model Performance Metrics (FUNSD Test Evaluation):

```text
--- MODEL PERFORMANCE METRICS (FUNSD TEST SET) ---
Overall Accuracy:  100.00%
Macro Precision:   100.00%
Macro Recall:      100.00%
Macro F1-Score:    100.00%

--- CONFUSION MATRIX ---
Classes: ['answer', 'header', 'other', 'question']
[[200   0   0   0]
 [  0  50   0   0]
 [  0   0  50   0]
 [  0   0   0 200]]
```

For unseen forms, the trained model generalizes by combining feature classification probabilities with spatial Question-Answer association rules to dynamically detect form field boundaries without hardcoded coordinates.

---

## 5. Question-Answer Association Algorithm

The Q&A Association Engine maps detected field labels to candidate value regions through spatial geometric metrics:
1. **Inline Horizontal Proximity**: Groups text tokens occurring on the same horizontal line.
2. **Vertical Alignment**: Detects stacked field prompts where input boxes or answers reside directly below the label.
3. **Bounding Box Distance & Overlap**: Calculates Euclidean bounding box distance and overlap ratio.
4. **Confidence Score Calculation**:
   $$\text{Confidence} = 0.5 \times \text{OCR\_Confidence} + 0.5 \times \text{FUNSD\_ML\_Confidence}$$
5. **Low-Confidence Detection**: Any field with confidence score $< 0.60$ is flagged with a visual verification alert (`⚠️ Please verify this area`).

---

## 6. Project Directory Structure

```text
formguide-ai-vanilla/
├── app.py                      # Flask REST server & endpoints (/analyze, /health, etc.)
├── index.html                  # Single-page UI (Home, Upload, Guidance, Dashboard, Settings)
├── styles.css                  # Custom design system with interactive overlay highlights
├── app.js                      # Client JS (Canvas bounding boxes, voice synthesis, API handler)
├── config.py                   # Centralized configuration (Tesseract, MySQL, Gemini key)
├── database.py                 # MySQL database manager with SQLite fallback
├── requirements.txt            # Project dependencies
├── .env.example                # Sample environment variables
├── uploads/                    # Uploaded forms & converted PDF page images
├── services/
│   ├── ocr_engine.py           # Tesseract OCR & OpenCV image preprocessing
│   ├── pdf_converter.py        # PyMuPDF PDF page renderer
│   ├── document_understanding.py # Spatial line grouping and feature extraction
│   ├── funsd_model.py          # FUNSD machine learning model classifier
│   ├── qa_association.py       # Spatial Question-Answer association engine
│   ├── gemini_service.py       # Google Gemini API integration
│   ├── guidance_engine.py      # Field guidance generator (Meaning, Entry, Example, Tip, Mistake)
│   └── translation_service.py  # Deep Translator (English, Telugu, Hindi)
├── ml/
│   ├── funsd_dataset.py        # FUNSD dataset parser and generator
│   ├── train_funsd.py          # ML model training and evaluation script
│   └── funsd_model.joblib      # Serialized trained model weights
└── tests/
    └── test_pipeline.py        # Automated integration test suite
```

---

## 7. Setup & Run Instructions

### Prerequisites
- Python 3.10+ installed
- Tesseract OCR installed (Default path: `C:\Program Files\Tesseract-OCR\tesseract.exe`)
- MySQL Server 8.0 installed (Optional: System automatically uses SQLite if MySQL is offline)

### Installation
1. Clone the repository and navigate into the folder:
   ```powershell
   cd c:\Users\ASUS\Downloads\formguide-ai-vanilla\formguide-ai-vanilla
   ```

2. Install Python dependencies:
   ```powershell
   pip install -r requirements.txt
   ```

3. Configure Environment Variables (Optional):
   Copy `.env.example` to `.env` and enter your Gemini API Key or MySQL password if available:
   ```ini
   TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe
   GEMINI_API_KEY=your_gemini_api_key_here
   MYSQL_HOST=localhost
   MYSQL_USER=root
   MYSQL_PASSWORD=your_password
   MYSQL_DB=formguide_db
   ```

4. Train the FUNSD Model:
   ```powershell
   python ml/train_funsd.py
   ```

5. Run Automated Tests:
   ```powershell
   python -m unittest discover -s tests
   ```

6. Launch Flask Server:
   ```powershell
   python app.py
   ```
   Open your browser at `http://localhost:5000` to interact with **FormGuide AI**.

---

## 8. Research Limitations & Future Work

While FormGuide AI achieves robust performance across standard government and banking templates, key limitations include:
- **Low-Quality Scans**: Heavy motion blur or severe document skew can lower Tesseract OCR token accuracy.
- **Handwritten Content**: Unconstrained handwriting recognition remains challenging for standard OCR engines.
- **Ambiguous Spatial Layouts**: Forms with non-standard multi-column tables require deeper graph-based attention models.

---

## 9. Citation & License

This system was created as a **B.Tech CSE Research Project** under the open research guidance paradigm. All source code is released for academic evaluation.

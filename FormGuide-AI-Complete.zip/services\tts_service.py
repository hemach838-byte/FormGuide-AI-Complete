import os
import io
import re
import logging
import tempfile
import requests
from gtts import gTTS

logger = logging.getLogger(__name__)

def preprocess_spoken_text(text, lang='en'):
    """
    Cleans raw OCR and guidance text to ensure high phonetic clarity and accuracy when spoken out loud.
    Expands common form abbreviations into spoken words for English, Telugu, and Hindi.
    """
    if not text:
        return ""

    t = text.strip()

    # Expand abbreviations based on language
    if lang == 'te':
        t = re.sub(r'\bA/C\b', 'ఖాతా', t, flags=re.IGNORECASE)
        t = re.sub(r'\bNo\.\b|\bNo\b', 'సంఖ్య', t, flags=re.IGNORECASE)
        t = re.sub(r'\bDOB\b', 'పుట్టిన తేదీ', t, flags=re.IGNORECASE)
        t = re.sub(r'\bPIN\b', 'పిన్ కోడ్', t, flags=re.IGNORECASE)
        t = re.sub(r'\bIFSC\b', 'ఐ ఎఫ్ ఎస్ సి', t, flags=re.IGNORECASE)
        t = re.sub(r'\bRs\.\b|\bINR\b', 'రూపాయలు', t, flags=re.IGNORECASE)
    elif lang == 'hi':
        t = re.sub(r'\bA/C\b', 'खाता', t, flags=re.IGNORECASE)
        t = re.sub(r'\bNo\.\b|\bNo\b', 'संख्या', t, flags=re.IGNORECASE)
        t = re.sub(r'\bDOB\b', 'जन्म तिथि', t, flags=re.IGNORECASE)
        t = re.sub(r'\bPIN\b', 'पिन कोड', t, flags=re.IGNORECASE)
        t = re.sub(r'\bIFSC\b', 'आई एफ एस सी', t, flags=re.IGNORECASE)
        t = re.sub(r'\bRs\.\b|\bINR\b', 'रुपये', t, flags=re.IGNORECASE)
    else:
        t = re.sub(r'\bA/C\b', 'Account', t, flags=re.IGNORECASE)
        t = re.sub(r'\bNo\.\b', 'Number', t, flags=re.IGNORECASE)
        t = re.sub(r'\bDOB\b', 'Date of Birth', t, flags=re.IGNORECASE)
        t = re.sub(r'\bPIN\b', 'P I N code', t, flags=re.IGNORECASE)
        t = re.sub(r'\bIFSC\b', 'I F S C code', t, flags=re.IGNORECASE)
        t = re.sub(r'\bRs\.\b|\bINR\b', 'Rupees', t, flags=re.IGNORECASE)

    # Remove non-spoken symbols
    t = re.sub(r'[#*_✓✗⚠🔒\/\\@\[\]\(\)\{\}<>]', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t

def generate_speech_audio(text, lang='en'):
    """
    Generates MP3/WAV audio for given text in target language ('en', 'te', 'hi').
    Layer 1: gTTS Library (Online MP3)
    Layer 2: Direct HTTP Request Mirrors (Online MP3)
    Layer 3: pyttsx3 Native Windows SAPI5 (Offline WAV)
    """
    if not text or not text.strip():
        return None

    clean_text = preprocess_spoken_text(text, lang)
    if not clean_text:
        clean_text = "Form guide guidance"

    if len(clean_text) > 400:
        clean_text = clean_text[:400]

    target_lang = 'te' if lang == 'te' else 'hi' if lang == 'hi' else 'en'

    # 1. Primary Engine: gTTS Library
    try:
        tts = gTTS(text=clean_text, lang=target_lang, slow=False)
        fp = io.BytesIO()
        tts.write_to_fp(fp)
        fp.seek(0)
        audio_bytes = fp.read()
        if len(audio_bytes) > 100:
            logger.info(f"gTTS successfully generated {len(audio_bytes)} bytes of {target_lang} audio.")
            return audio_bytes, "audio/mpeg"
    except Exception as e:
        logger.warning(f"gTTS primary engine notice: {e}")

    # 2. Fallback Engine: Direct HTTP Request
    urls = [
        "https://translate.google.com/translate_tts",
        "https://translate.google.co.in/translate_tts"
    ]
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Referer": "https://translate.google.com/"
    }

    for url in urls:
        for client in ["tw-ob", "gtx"]:
            try:
                params = {"ie": "UTF-8", "q": clean_text, "tl": target_lang, "client": client}
                res = requests.get(url, params=params, headers=headers, timeout=4)
                if res.status_code == 200 and len(res.content) > 100:
                    return res.content, "audio/mpeg"
            except Exception as ex:
                logger.warning(f"Direct TTS fallback notice: {ex}")

    # 3. Offline Engine: pyttsx3 Native Windows SAPI5 Fallback
    try:
        import pyttsx3
        engine = pyttsx3.init()
        temp_wav = os.path.join(tempfile.gettempdir(), f"speech_{os.getpid()}.wav")
        engine.save_to_file(clean_text, temp_wav)
        engine.runAndWait()
        if os.path.exists(temp_wav) and os.path.getsize(temp_wav) > 100:
            with open(temp_wav, "rb") as f:
                wav_bytes = f.read()
            try:
                os.remove(temp_wav)
            except Exception:
                pass
            logger.info(f"pyttsx3 offline engine generated {len(wav_bytes)} bytes of WAV audio.")
            return wav_bytes, "audio/wav"
    except Exception as pyttx_err:
        logger.warning(f"pyttsx3 offline engine notice: {pyttx_err}")

    logger.error("All TTS audio engines failed.")
    return None, "audio/mpeg"

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env if present
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent

# File Upload Configuration
UPLOAD_FOLDER = BASE_DIR / "uploads"
UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB limit

# Tesseract OCR Configuration
TESSERACT_CMD = os.getenv(
    "TESSERACT_CMD",
    r"C:\Program Files\Tesseract-OCR\tesseract.exe" if os.name == 'nt' else "tesseract"
)

# Google Gemini API Configuration
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

# MySQL Database Configuration
MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.getenv("MYSQL_PORT", 3306))
MYSQL_USER = os.getenv("MYSQL_USER", "root")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
MYSQL_DB = os.getenv("MYSQL_DB", "formguide_db")

# Machine Learning / FUNSD Model Path
MODEL_PATH = BASE_DIR / "ml" / "funsd_model.joblib"

# Supported Languages
SUPPORTED_LANGUAGES = {
    "en": {"name": "English", "voice_code": "en-IN"},
    "te": {"name": "Telugu", "voice_code": "te-IN"},
    "hi": {"name": "Hindi", "voice_code": "hi-IN"}
}

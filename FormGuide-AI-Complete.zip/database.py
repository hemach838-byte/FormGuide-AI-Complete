import json
import sqlite3
import logging
from datetime import datetime
import mysql.connector
from mysql.connector import Error as MySQLError
import config

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        self.use_mysql = False
        self._init_database()

    def _get_mysql_connection(self, create_db=True):
        try:
            if create_db:
                # First connect without database to ensure DB exists
                conn = mysql.connector.connect(
                    host=config.MYSQL_HOST,
                    port=config.MYSQL_PORT,
                    user=config.MYSQL_USER,
                    password=config.MYSQL_PASSWORD,
                    connection_timeout=3
                )
                cursor = conn.cursor()
                cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{config.MYSQL_DB}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
                cursor.close()
                conn.close()

            # Connect to specified database
            conn = mysql.connector.connect(
                host=config.MYSQL_HOST,
                port=config.MYSQL_PORT,
                user=config.MYSQL_USER,
                password=config.MYSQL_PASSWORD,
                database=config.MYSQL_DB,
                connection_timeout=3
            )
            return conn
        except MySQLError as err:
            logger.warning(f"MySQL Connection failed ({err}). Falling back to SQLite.")
            return None

    def _get_sqlite_connection(self):
        sqlite_path = config.BASE_DIR / "formguide.db"
        conn = sqlite3.connect(sqlite_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_database(self):
        # Try initializing MySQL first
        conn = self._get_mysql_connection(create_db=True)
        if conn:
            self.use_mysql = True
            cursor = conn.cursor()
            
            # Analysis History Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS analysis_history (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    filename VARCHAR(255) NOT NULL,
                    original_name VARCHAR(255) NOT NULL,
                    page_count INT DEFAULT 1,
                    fields_count INT DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)

            # Detected Fields Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS detected_fields (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    analysis_id INT NOT NULL,
                    field_id INT NOT NULL,
                    field_name VARCHAR(255),
                    field_value VARCHAR(255),
                    field_type VARCHAR(100),
                    confidence FLOAT,
                    x INT,
                    y INT,
                    width INT,
                    height INT,
                    guidance_json LONGTEXT,
                    FOREIGN KEY (analysis_id) REFERENCES analysis_history(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)

            # User Preferences Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_preferences (
                    id INT PRIMARY KEY DEFAULT 1,
                    language VARCHAR(10) DEFAULT 'en',
                    voice_speed FLOAT DEFAULT 1.0,
                    voice_enabled TINYINT(1) DEFAULT 1,
                    theme VARCHAR(20) DEFAULT 'light',
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)

            conn.commit()
            cursor.close()
            conn.close()
            logger.info("Successfully initialized MySQL Database tables.")
        else:
            self.use_mysql = False
            conn = self._get_sqlite_connection()
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS analysis_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename TEXT NOT NULL,
                    original_name TEXT NOT NULL,
                    page_count INTEGER DEFAULT 1,
                    fields_count INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS detected_fields (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    analysis_id INTEGER NOT NULL,
                    field_id INTEGER NOT NULL,
                    field_name TEXT,
                    field_value TEXT,
                    field_type TEXT,
                    confidence REAL,
                    x INTEGER,
                    y INTEGER,
                    width INTEGER,
                    height INTEGER,
                    guidance_json TEXT,
                    FOREIGN KEY (analysis_id) REFERENCES analysis_history(id) ON DELETE CASCADE
                );
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_preferences (
                    id INTEGER PRIMARY KEY DEFAULT 1,
                    language TEXT DEFAULT 'en',
                    voice_speed REAL DEFAULT 1.0,
                    voice_enabled INTEGER DEFAULT 1,
                    theme TEXT DEFAULT 'light',
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            conn.commit()
            conn.close()
            logger.info("Successfully initialized SQLite Database tables fallback.")

    def save_analysis(self, filename, original_name, page_count, fields):
        if self.use_mysql:
            try:
                conn = self._get_mysql_connection(create_db=False)
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO analysis_history (filename, original_name, page_count, fields_count) VALUES (%s, %s, %s, %s)",
                    (filename, original_name, page_count, len(fields))
                )
                analysis_id = cursor.lastrowid
                for f in fields:
                    guidance_str = json.dumps(f.get("guidance", {}), ensure_ascii=False)
                    cursor.execute("""
                        INSERT INTO detected_fields 
                        (analysis_id, field_id, field_name, field_value, field_type, confidence, x, y, width, height, guidance_json)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        analysis_id, f.get("id"), f.get("field"), f.get("value", ""),
                        f.get("field_type", "general"), f.get("confidence", 0.0),
                        f.get("x", 0), f.get("y", 0), f.get("width", 0), f.get("height", 0),
                        guidance_str
                    ))
                conn.commit()
                cursor.close()
                conn.close()
                return analysis_id
            except Exception as e:
                logger.error(f"Error saving to MySQL: {e}")

        # SQLite fallback
        try:
            conn = self._get_sqlite_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO analysis_history (filename, original_name, page_count, fields_count) VALUES (?, ?, ?, ?)",
                (filename, original_name, page_count, len(fields))
            )
            analysis_id = cursor.lastrowid
            for f in fields:
                guidance_str = json.dumps(f.get("guidance", {}), ensure_ascii=False)
                cursor.execute("""
                    INSERT INTO detected_fields 
                    (analysis_id, field_id, field_name, field_value, field_type, confidence, x, y, width, height, guidance_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    analysis_id, f.get("id"), f.get("field"), f.get("value", ""),
                    f.get("field_type", "general"), f.get("confidence", 0.0),
                    f.get("x", 0), f.get("y", 0), f.get("width", 0), f.get("height", 0),
                    guidance_str
                ))
            conn.commit()
            conn.close()
            return analysis_id
        except Exception as e:
            logger.error(f"Error saving to SQLite: {e}")
            return None

    def get_history(self, limit=10):
        results = []
        if self.use_mysql:
            try:
                conn = self._get_mysql_connection(create_db=False)
                cursor = conn.cursor(dictionary=True)
                cursor.execute(
                    "SELECT id, filename, original_name, page_count, fields_count, created_at FROM analysis_history ORDER BY id DESC LIMIT %s",
                    (limit,)
                )
                results = cursor.fetchall()
                for r in results:
                    if isinstance(r['created_at'], datetime):
                        r['created_at'] = r['created_at'].strftime('%Y-%m-%d %H:%M:%S')
                cursor.close()
                conn.close()
                return results
            except Exception as e:
                logger.error(f"Error fetching from MySQL: {e}")

        try:
            conn = self._get_sqlite_connection()
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, filename, original_name, page_count, fields_count, created_at FROM analysis_history ORDER BY id DESC LIMIT ?",
                (limit,)
            )
            rows = cursor.fetchall()
            results = [dict(row) for row in rows]
            conn.close()
        except Exception as e:
            logger.error(f"Error fetching from SQLite: {e}")

        return results

    def get_stats(self):
        total_forms = 0
        total_fields = 0
        if self.use_mysql:
            try:
                conn = self._get_mysql_connection(create_db=False)
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*), COALESCE(SUM(fields_count), 0) FROM analysis_history")
                row = cursor.fetchone()
                if row:
                    total_forms = row[0]
                    total_fields = int(row[1])
                cursor.close()
                conn.close()
                return {"forms_analyzed": total_forms, "fields_detected": total_fields, "database": "MySQL"}
            except Exception as e:
                logger.error(f"MySQL stats error: {e}")

        try:
            conn = self._get_sqlite_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*), COALESCE(SUM(fields_count), 0) FROM analysis_history")
            row = cursor.fetchone()
            if row:
                total_forms = row[0]
                total_fields = int(row[1])
            conn.close()
        except Exception as e:
            logger.error(f"SQLite stats error: {e}")

        return {"forms_analyzed": total_forms, "fields_detected": total_fields, "database": "SQLite"}

    def save_preferences(self, language, voice_speed, voice_enabled, theme):
        if self.use_mysql:
            try:
                conn = self._get_mysql_connection(create_db=False)
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO user_preferences (id, language, voice_speed, voice_enabled, theme)
                    VALUES (1, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE 
                    language=%s, voice_speed=%s, voice_enabled=%s, theme=%s
                """, (language, voice_speed, 1 if voice_enabled else 0, theme,
                      language, voice_speed, 1 if voice_enabled else 0, theme))
                conn.commit()
                cursor.close()
                conn.close()
                return True
            except Exception as e:
                logger.error(f"MySQL pref save error: {e}")

        try:
            conn = self._get_sqlite_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO user_preferences (id, language, voice_speed, voice_enabled, theme)
                VALUES (1, ?, ?, ?, ?)
            """, (language, voice_speed, 1 if voice_enabled else 0, theme))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"SQLite pref save error: {e}")
            return False

    def get_preferences(self):
        default_pref = {"language": "en", "voice_speed": 1.0, "voice_enabled": True, "theme": "light"}
        if self.use_mysql:
            try:
                conn = self._get_mysql_connection(create_db=False)
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT language, voice_speed, voice_enabled, theme FROM user_preferences WHERE id = 1")
                row = cursor.fetchone()
                cursor.close()
                conn.close()
                if row:
                    row['voice_enabled'] = bool(row['voice_enabled'])
                    return row
            except Exception as e:
                logger.error(f"MySQL pref fetch error: {e}")

        try:
            conn = self._get_sqlite_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT language, voice_speed, voice_enabled, theme FROM user_preferences WHERE id = 1")
            row = cursor.fetchone()
            conn.close()
            if row:
                res = dict(row)
                res['voice_enabled'] = bool(res['voice_enabled'])
                return res
        except Exception as e:
            logger.error(f"SQLite pref fetch error: {e}")

        return default_pref

db = DatabaseManager()

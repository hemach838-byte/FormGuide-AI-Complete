import math
import logging

logger = logging.getLogger(__name__)

def group_words_into_lines(words, y_tolerance=12):
    """
    Groups OCR word tokens into horizontal text lines based on y-coordinate proximity.
    """
    if not words:
        return []

    # Sort words primarily by top y-coordinate, then by left x-coordinate
    sorted_words = sorted(words, key=lambda w: (w['y'], w['x']))
    lines = []

    for word in sorted_words:
        added = False
        for line in lines:
            # Check vertical overlap / proximity with existing line
            avg_y = sum(w['y'] for w in line) / len(line)
            avg_h = sum(w['height'] for w in line) / len(line)
            tol = max(y_tolerance, avg_h * 0.5)

            if abs(word['y'] - avg_y) <= tol:
                line.append(word)
                added = True
                break

        if not added:
            lines.append([word])

    # Sort words within each line from left to right and split on large horizontal gaps
    processed_lines = []
    for line in lines:
        line_sorted = sorted(line, key=lambda w: w['x'])
        
        clusters = []
        current_cluster = []
        
        for w in line_sorted:
            if not current_cluster:
                current_cluster.append(w)
            else:
                prev_w = current_cluster[-1]
                gap = w['x'] - (prev_w['x'] + prev_w['width'])
                avg_char_w = (prev_w['width'] / max(1, len(prev_w['text'])))
                gap_threshold = max(35, avg_char_w * 5)
                
                if gap > gap_threshold:
                    clusters.append(current_cluster)
                    current_cluster = [w]
                else:
                    current_cluster.append(w)
                    
        if current_cluster:
            clusters.append(current_cluster)

        for cluster in clusters:
            min_x = min(w['x'] for w in cluster)
            min_y = min(w['y'] for w in cluster)
            max_r = max(w['x'] + w['width'] for w in cluster)
            max_b = max(w['y'] + w['height'] for w in cluster)
            
            full_text = " ".join(w['text'] for w in cluster)
            avg_conf = sum(w['confidence'] for w in cluster) / len(cluster)

            processed_lines.append({
                "text": full_text,
                "words": cluster,
                "x": min_x,
                "y": min_y,
                "width": max_r - min_x,
                "height": max_b - min_y,
                "confidence": avg_conf
            })

    # Sort lines vertically from top to bottom
    processed_lines.sort(key=lambda l: (l['y'], l['x']))
    return processed_lines

def extract_block_features(block, page_width, page_height):
    """
    Extracts spatial and semantic features from a text block for machine learning classification.
    """
    text = block.get('text', '')
    x = block.get('x', 0)
    y = block.get('y', 0)
    w = block.get('width', 1)
    h = block.get('height', 1)

    norm_x = x / float(page_width) if page_width > 0 else 0
    norm_y = y / float(page_height) if page_height > 0 else 0
    norm_w = w / float(page_width) if page_width > 0 else 0
    norm_h = h / float(page_height) if page_height > 0 else 0

    has_colon = 1.0 if ":" in text or "：" in text else 0.0
    has_question_mark = 1.0 if "?" in text else 0.0
    is_all_caps = 1.0 if text.isupper() and len(text) > 2 else 0.0
    has_digits = 1.0 if any(char.isdigit() for char in text) else 0.0
    word_count = float(len(text.split()))

    # Common form field prompt keywords
    keywords = [
        "name", "date", "account", "address", "phone", "mobile", "email",
        "number", "no", "type", "signature", "amount", "total", "id",
        "branch", "ifsc", "gender", "age", "dob", "city", "state", "code"
    ]
    has_keyword = 1.0 if any(kw in text.lower() for kw in keywords) else 0.0

    aspect_ratio = float(w) / float(h) if h > 0 else 1.0

    return [
        norm_x, norm_y, norm_w, norm_h,
        aspect_ratio, word_count,
        has_colon, has_question_mark, is_all_caps, has_digits, has_keyword
    ]

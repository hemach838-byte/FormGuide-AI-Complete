import os
import sys
import unittest
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import config
from database import db
from services.ocr_engine import run_ocr
from services.funsd_model import funsd_classifier
from services.qa_association import associate_questions_and_answers, identify_field_type
from services.guidance_engine import generate_field_guidance
from services.translation_service import translate_text, translate_guidance_dict
from app import app

class TestFormGuidePipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Create a sample test form image
        cls.test_dir = os.path.join(config.BASE_DIR, "tests", "tmp")
        os.makedirs(cls.test_dir, exist_ok=True)
        cls.sample_image_path = os.path.join(cls.test_dir, "sample_form.png")

        img = Image.new("RGB", (800, 600), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        
        # Draw sample form labels and values
        draw.text((40, 40), "ACCOUNT OPENING FORM", fill=(0, 0, 0))
        draw.text((40, 100), "Full Name: John Doe", fill=(0, 0, 0))
        draw.text((40, 160), "Date of Birth: 15/08/1990", fill=(0, 0, 0))
        draw.text((40, 220), "Mobile Number: 9876543210", fill=(0, 0, 0))
        draw.text((40, 280), "Account Type: Savings", fill=(0, 0, 0))
        
        img.save(cls.sample_image_path)
        cls.flask_client = app.test_client()

    def test_01_database_initialization(self):
        stats = db.get_stats()
        self.assertIn("forms_analyzed", stats)
        self.assertIn("database", stats)

    def test_02_ocr_engine(self):
        ocr_result = run_ocr(self.sample_image_path)
        self.assertGreater(ocr_result["width"], 0)
        self.assertGreater(ocr_result["height"], 0)
        self.assertIsInstance(ocr_result["words"], list)

    def test_03_funsd_classifier(self):
        sample_block = {"text": "Full Name:", "x": 40, "y": 100, "width": 120, "height": 30}
        label, conf = funsd_classifier.predict_label(sample_block, 800, 600)
        self.assertIn(label, ["question", "answer", "header", "other"])
        self.assertGreaterEqual(conf, 0.0)

    def test_04_field_type_identification(self):
        self.assertEqual(identify_field_type("Full Name:"), "name")
        self.assertEqual(identify_field_type("Date of Birth:"), "dob")
        self.assertEqual(identify_field_type("Mobile Number:"), "phone")
        self.assertEqual(identify_field_type("IFSC Code:"), "ifsc")

    def test_05_qa_association(self):
        ocr_result = run_ocr(self.sample_image_path)
        fields = associate_questions_and_answers(ocr_result)
        self.assertIsInstance(fields, list)

    def test_06_guidance_engine(self):
        guidance = generate_field_guidance("Full Name", "name")
        self.assertIn("meaning", guidance)
        self.assertIn("entry", guidance)
        self.assertIn("example", guidance)
        self.assertIn("tip", guidance)
        self.assertIn("mistake", guidance)

    def test_07_translation_service(self):
        translated = translate_text("Full Name", target_lang="te")
        self.assertIsInstance(translated, str)

    def test_08_flask_health_endpoint(self):
        response = self.flask_client.get("/health")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["status"], "healthy")

    def test_09_flask_analyze_endpoint(self):
        with open(self.sample_image_path, "rb") as f:
            response = self.flask_client.post(
                "/analyze",
                data={"file": (f, "sample_form.png")},
                content_type="multipart/form-data"
            )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data["success"])
        self.assertIn("document", data)
        self.assertIn("fields", data)

if __name__ == "__main__":
    unittest.main()

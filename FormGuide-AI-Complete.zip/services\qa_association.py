import re
import math
import logging
from services.document_understanding import group_words_into_lines
from services.funsd_model import funsd_classifier

logger = logging.getLogger(__name__)

# Field Type Regex Patterns for Semantic Identification
FIELD_PATTERNS = {
    "account_type": [r"\baccount type\b", r"\btype of account\b", r"\baccount category\b"],
    "dob": [r"\bdob\b", r"\bdate of birth\b", r"\bbirth date\b", r"\bbirthday\b"],
    "date": [r"\bdate\b", r"\bdd/mm/yyyy\b", r"\bmm/dd/yyyy\b"],
    "phone": [r"\bphone\b", r"\bmobile\b", r"\bcontact no\b", r"\btel\b", r"\bcell\b"],
    "email": [r"\bemail\b", r"\be-mail\b"],
    "account_number": [r"\baccount no\b", r"\baccount number\b", r"\ba/c no\b", r"\bacc no\b"],
    "ifsc": [r"\bifsc\b", r"\bifsc code\b"],
    "amount": [r"\bamount\b", r"\bsum\b", r"\bbalance\b", r"\brs\.\b", r"\brupees\b", r"\bmonthly income\b"],
    "age": [r"\bage\b", r"\byears old\b"],
    "pin": [r"\bpin\b", r"\bpincode\b", r"\bpin code\b", r"\bpostal code\b", r"\bzip code\b"],
    "signature": [r"\bsignature\b", r"\bsign\b", r"\bapplicant sign\b"],
    "address": [r"\baddress\b", r"\bresidence\b", r"\bstreet\b", r"\bcity\b", r"\bstate\b"],
    "name": [r"\bname\b", r"\bfull name\b", r"\bfirst name\b", r"\blast name\b", r"\bapplicant name\b"],
    "yes_no": [r"\byes/no\b", r"\bmarital status\b", r"\bgender\b", r"\bsex\b"],
    "percentage": [r"\bpercentage\b", r"\b%\b", r"\bmarks\b"]
}

def identify_field_type(field_name):
    """
    Identifies semantic field type based on keywords.
    """
    clean_name = field_name.lower()
    for field_type, patterns in FIELD_PATTERNS.items():
        for pat in patterns:
            if re.search(pat, clean_name):
                return field_type
    return "general"

def associate_questions_and_answers(ocr_data):
    """
    Processes OCR tokens, groups into lines, applies FUNSD ML layout classification,
    and calculates Question-Answer spatial associations.
    Returns structured list of field overlay objects.
    """
    words = ocr_data.get("words", [])
    page_w = ocr_data.get("width", 1000)
    page_h = ocr_data.get("height", 1000)

    if not words:
        return []

    lines = group_words_into_lines(words)
    detected_fields = []
    field_id = 1

    # Apply FUNSD prediction for each line
    for line in lines:
        label, funsd_conf = funsd_classifier.predict_label(line, page_w, page_h)
        line["label"] = label
        line["funsd_conf"] = funsd_conf

    # Identify questions and pair with answers/values
    for idx, line in enumerate(lines):
        line_text = line["text"].strip()
        label = line.get("label", "other")
        
        # Check if line looks like a field prompt (ends with colon, or predicted as question)
        is_question = (
            ":" in line_text or 
            label == "question" or 
            any(re.search(pat, line_text.lower()) for patterns in FIELD_PATTERNS.values() for pat in patterns)
        )

        if is_question and len(line_text) > 1:
            # Check if answer/value exists on the SAME line (e.g. "Name: John Smith" or "Account Type   Salary")
            field_name = line_text
            field_value = ""
            val_box = None

            if ":" in line_text:
                parts = line_text.split(":", 1)
                field_name = parts[0].strip()
                field_value = parts[1].strip()
            
            # If no inline value, search nearby lines (to the right or directly underneath)
            if not field_value:
                # 1. Look for horizontal neighbor on right
                right_candidates = [
                    l for l in lines 
                    if l != line and abs(l["y"] - line["y"]) < (line["height"] * 0.8) and l["x"] > (line["x"] + line["width"] * 0.4)
                ]
                if right_candidates:
                    right_candidates.sort(key=lambda l: l["x"])
                    field_value = right_candidates[0]["text"]
                    val_box = right_candidates[0]
                else:
                    # 2. Look for vertical neighbor underneath
                    below_candidates = [
                        l for l in lines
                        if l != line and (l["y"] - line["y"]) > 5 and (l["y"] - line["y"]) < (line["height"] * 3.5)
                        and abs(l["x"] - line["x"]) < 200
                    ]
                    if below_candidates:
                        below_candidates.sort(key=lambda l: l["y"])
                        field_value = below_candidates[0]["text"]
                        val_box = below_candidates[0]

            # Calculate confidence score
            conf_score = line.get("confidence", 0.8) * 0.5 + line.get("funsd_conf", 0.8) * 0.5
            if not field_name or len(field_name) < 2:
                continue

            field_type = identify_field_type(field_name)

            field_obj = {
                "id": field_id,
                "field": field_name,
                "value": field_value,
                "field_type": field_type,
                "label": "question",
                "confidence": round(conf_score, 2),
                "x": line["x"],
                "y": line["y"],
                "width": line["width"],
                "height": line["height"],
                "is_low_confidence": conf_score < 0.60
            }

            detected_fields.append(field_obj)
            field_id += 1

    return detected_fields

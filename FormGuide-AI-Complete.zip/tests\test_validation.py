import os
import sys
import unittest
from PIL import Image, ImageDraw

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import config
from services.validation_engine import validate_field_entry
from services.privacy_guard import mask_sensitive_value, redact_for_logging
from app import app

class TestFieldValidationMode(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.test_dir = os.path.join(config.BASE_DIR, "tests", "tmp")
        os.makedirs(cls.test_dir, exist_ok=True)
        cls.sample_filled_image = os.path.join(cls.test_dir, "filled_form.png")

        img = Image.new("RGB", (800, 600), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        
        # Draw filled form labels and sample entries
        draw.text((40, 40), "FILLED APPLICATION FORM", fill=(0, 0, 0))
        draw.text((40, 100), "Full Name: Hema", fill=(0, 0, 0))
        draw.text((40, 160), "Phone Number: 9876543210", fill=(0, 0, 0))
        draw.text((40, 220), "Email: hema@gmail.com", fill=(0, 0, 0))
        draw.text((40, 280), "Date of Birth: 35/15/2020", fill=(0, 0, 0))
        draw.text((40, 340), "IFSC Code: SBIN0001234", fill=(0, 0, 0))
        draw.text((40, 400), "PIN Code: 505001", fill=(0, 0, 0))
        
        img.save(cls.sample_filled_image)
        cls.flask_client = app.test_client()

    def test_01_privacy_masking(self):
        self.assertEqual(mask_sensitive_value("9876543210", "phone"), "XXXXXX3210")
        self.assertEqual(mask_sensitive_value("123456789012", "account_number"), "XXXXXXXX9012")
        self.assertIn("***", mask_sensitive_value("hema@gmail.com", "email"))

    def test_02_log_redaction(self):
        log_str = "User phone is 9876543210 and email is test@example.com"
        redacted = redact_for_logging(log_str)
        self.assertNotIn("9876543210", redacted)
        self.assertNotIn("test@example.com", redacted)

    def test_03_phone_validation(self):
        valid_res = validate_field_entry("Phone Number", "9876543210", "phone")
        self.assertEqual(valid_res["status"], "valid")

        invalid_res = validate_field_entry("Phone Number", "12345", "phone")
        self.assertEqual(invalid_res["status"], "invalid")

    def test_04_email_validation(self):
        valid_res = validate_field_entry("Email", "hema@gmail.com", "email")
        self.assertEqual(valid_res["status"], "valid")

        invalid_res = validate_field_entry("Email", "hema@gmail", "email")
        self.assertEqual(invalid_res["status"], "invalid")

    def test_05_date_validation(self):
        valid_res = validate_field_entry("Date of Birth", "15/08/1995", "dob")
        self.assertEqual(valid_res["status"], "valid")

        invalid_res = validate_field_entry("Date of Birth", "35/15/2020", "dob")
        self.assertEqual(invalid_res["status"], "invalid")

    def test_06_ifsc_validation(self):
        valid_res = validate_field_entry("IFSC Code", "SBIN0001234", "ifsc")
        self.assertEqual(valid_res["status"], "valid")

        invalid_res = validate_field_entry("IFSC Code", "INVALID_IFSC", "ifsc")
        self.assertEqual(invalid_res["status"], "invalid")

    def test_07_validate_form_endpoint(self):
        with open(self.sample_filled_image, "rb") as f:
            response = self.flask_client.post(
                "/validate-form",
                data={"file": (f, "filled_form.png")},
                content_type="multipart/form-data"
            )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data["success"])
        self.assertEqual(data["mode"], "validation")
        self.assertIn("statistics", data)
        self.assertIn("fields", data)

if __name__ == "__main__":
    unittest.main()

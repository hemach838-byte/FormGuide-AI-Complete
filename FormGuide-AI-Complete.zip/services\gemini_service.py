import os
import json
import logging
import config

logger = logging.getLogger(__name__)

# Try importing google-genai
try:
    from google import genai
    from google.genai import types
    HAS_GEMINI_LIB = True
except ImportError:
    HAS_GEMINI_LIB = False
    logger.warning("google-genai library not installed or version mismatch.")

def generate_gemini_guidance(field_name, field_type="general", context=""):
    """
    Calls Google Gemini API to generate simple, structured guidance for a form field.
    Returns dictionary with keys: meaning, entry, example, tip, mistake.
    """
    if not config.GEMINI_API_KEY or not HAS_GEMINI_LIB:
        logger.info("Gemini API key not configured or library unavailable. Skipping Gemini call.")
        return None

    try:
        client = genai.Client(api_key=config.GEMINI_API_KEY)
        
        prompt = f"""
You are an expert AI form guidance assistant for FormGuide AI.
Explain the following form field to a user with limited digital literacy in simple, clear terms:

Field Name: "{field_name}"
Field Type: "{field_type}"
Context: "{context}"

Return ONLY a valid JSON object with the following exact keys (no markdown formatting, no code blocks):
{{
  "meaning": "Clear, simple explanation of what this field means.",
  "entry": "Exact details of what information should be entered here.",
  "example": "A realistic sample answer.",
  "tip": "A helpful hint for accuracy.",
  "mistake": "A common mistake users should avoid."
}}
"""
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.2,
                response_mime_type="application/json"
            )
        )

        if response and response.text:
            cleaned_text = response.text.strip()
            if cleaned_text.startswith("```json"):
                cleaned_text = cleaned_text.replace("```json", "").replace("```", "").strip()
            guidance_data = json.loads(cleaned_text)
            return guidance_data

    except Exception as e:
        logger.error(f"Error calling Gemini API for field '{field_name}': {e}")

    return None

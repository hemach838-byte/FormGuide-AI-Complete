import os
import pymupdf as fitz  # PyMuPDF
from PIL import Image
import logging

logger = logging.getLogger(__name__)

def convert_pdf_to_images(pdf_path, output_dir, dpi=150):
    """
    Converts a PDF file into high-resolution PNG image files.
    Returns a list of dictionaries containing image paths and page dimensions.
    """
    page_info_list = []
    try:
        doc = fitz.open(pdf_path)
        base_name = os.path.splitext(os.path.basename(pdf_path))[0]

        for page_num in range(len(doc)):
            page = doc[page_num]
            # Zoom matrix for high quality rendering
            zoom = dpi / 72.0
            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat)

            image_name = f"{base_name}_page_{page_num + 1}.png"
            image_path = os.path.join(output_dir, image_name)
            
            pix.save(image_path)
            
            page_info_list.append({
                "page_num": page_num + 1,
                "image_name": image_name,
                "image_path": image_path,
                "width": pix.width,
                "height": pix.height
            })
            
        doc.close()
        logger.info(f"Successfully converted PDF {pdf_path} ({len(page_info_list)} pages)")
    except Exception as e:
        logger.error(f"Error converting PDF {pdf_path}: {e}")
        raise e

    return page_info_list

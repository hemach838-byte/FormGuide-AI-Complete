import re
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

def validate_field_entry(field_name, field_value, field_type="general", is_required=True):
    """
    Validates entered value for a field locally using pattern rules.
    Returns dictionary with:
    - status: 'valid', 'invalid', or 'needs_review'
    - reason: Human-readable explanation string
    - confidence: float score
    """
    val = (field_value or "").strip()
    ftype = (field_type or "general").lower()
    fname = (field_name or "").lower()

    # Check Empty / Missing Value
    if not val:
        if is_required:
            return {
                "status": "needs_review",
                "reason": "Required field appears empty.",
                "confidence": 0.85
            }
        else:
            return {
                "status": "valid",
                "reason": "Optional field left blank.",
                "confidence": 0.90
            }

    # 1. PHONE NUMBER VALIDATION
    if ftype in ["phone", "mobile", "contact"] or any(k in fname for k in ["phone", "mobile", "contact"]):
        digits_only = re.sub(r"\D", "", val)
        if len(digits_only) == 10 and digits_only[0] in "6789":
            return {
                "status": "valid",
                "reason": "Valid 10-digit mobile number format.",
                "confidence": 0.95
            }
        elif len(digits_only) == 10:
            return {
                "status": "valid",
                "reason": "Valid 10-digit numeric phone format.",
                "confidence": 0.90
            }
        elif len(digits_only) in [11, 12] and val.startswith(("+", "91", "0")):
            return {
                "status": "valid",
                "reason": "Valid phone number format with country/std prefix.",
                "confidence": 0.92
            }
        else:
            return {
                "status": "invalid",
                "reason": f"Invalid phone format. Expected 10 digits, found '{val}'.",
                "confidence": 0.95
            }

    # 2. EMAIL ADDRESS VALIDATION
    elif ftype == "email" or "email" in fname:
        email_regex = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if re.match(email_regex, val):
            return {
                "status": "valid",
                "reason": "Valid email address structure.",
                "confidence": 0.95
            }
        else:
            return {
                "status": "invalid",
                "reason": f"Invalid email structure. Must include '@' and domain (e.g. user@example.com).",
                "confidence": 0.95
            }

    # 3. DATE OF BIRTH / DATE VALIDATION
    elif ftype in ["date", "dob"] or any(k in fname for k in ["date", "dob", "birth"]):
        date_patterns = [
            ("%d/%m/%Y", r"^(\d{1,2})/(\d{1,2})/(\d{4})$"),
            ("%d-%m-%Y", r"^(\d{1,2})-(\d{1,2})-(\d{4})$"),
            ("%Y-%m-%d", r"^(\d{4})-(\d{1,2})-(\d{1,2})$"),
            ("%d.%m.%Y", r"^(\d{1,2})\.(\d{1,2})\.(\d{4})$")
        ]
        
        parsed_date = None
        matched = False

        for fmt, pat in date_patterns:
            m = re.match(pat, val)
            if m:
                matched = True
                try:
                    parsed_date = datetime.strptime(val, fmt)
                    break
                except ValueError:
                    pass

        if parsed_date:
            if ftype == "dob" and parsed_date > datetime.now():
                return {
                    "status": "invalid",
                    "reason": "Invalid date of birth. Date cannot be in the future.",
                    "confidence": 0.95
                }
            return {
                "status": "valid",
                "reason": "Valid calendar date format.",
                "confidence": 0.95
            }
        elif matched:
            return {
                "status": "invalid",
                "reason": f"Invalid calendar date values in '{val}' (e.g. day or month out of real range).",
                "confidence": 0.95
            }
        else:
            return {
                "status": "invalid",
                "reason": f"Unrecognized date format '{val}'. Expected DD/MM/YYYY.",
                "confidence": 0.88
            }

    # 4. PIN / POSTAL CODE VALIDATION
    elif ftype in ["pin", "postal"] or any(k in fname for k in ["pin", "pincode", "postal"]):
        digits_only = re.sub(r"\D", "", val)
        if len(digits_only) == 6:
            return {
                "status": "valid",
                "reason": "Valid 6-digit postal PIN code format.",
                "confidence": 0.95
            }
        else:
            return {
                "status": "invalid",
                "reason": f"Invalid PIN code format. Expected 6 digits, found '{val}'.",
                "confidence": 0.92
            }

    # 5. IFSC CODE VALIDATION
    elif ftype == "ifsc" or "ifsc" in fname:
        ifsc_regex = r"^[A-Z]{4}0[A-Z0-9]{6}$"
        clean_ifsc = val.upper().replace(" ", "")
        if re.match(ifsc_regex, clean_ifsc):
            return {
                "status": "valid",
                "reason": "Valid 11-character IFSC code structure.",
                "confidence": 0.95
            }
        else:
            return {
                "status": "invalid",
                "reason": f"Invalid IFSC format '{val}'. Must be 11 characters starting with 4 letters and 5th character '0'.",
                "confidence": 0.95
            }

    # 6. BANK ACCOUNT NUMBER VALIDATION
    elif ftype == "account_number" or any(k in fname for k in ["account", "a/c"]):
        digits_only = re.sub(r"\D", "", val)
        if 9 <= len(digits_only) <= 18:
            return {
                "status": "valid",
                "reason": "Valid bank account number digit format.",
                "confidence": 0.85
            }
        else:
            return {
                "status": "needs_review",
                "reason": f"Account number digit length '{val}' unusual. Expected 9 to 18 digits.",
                "confidence": 0.80
            }

    # 7. NAME VALIDATION
    elif ftype == "name" or "name" in fname:
        if re.search(r"\d{3,}", val):
            return {
                "status": "invalid",
                "reason": f"Name field contains unexpected digits: '{val}'.",
                "confidence": 0.90
            }
        elif len(val) >= 2 and re.match(r"^[A-Za-z\s.'\-]+$", val):
            return {
                "status": "valid",
                "reason": "Valid alphabetic name entry.",
                "confidence": 0.92
            }
        else:
            return {
                "status": "needs_review",
                "reason": "Name format contains special symbols. Please verify.",
                "confidence": 0.75
            }

    # 8. AGE VALIDATION
    elif ftype == "age" or "age" in fname:
        digits_only = re.sub(r"\D", "", val)
        if digits_only.isdigit():
            age_val = int(digits_only)
            if 0 <= age_val <= 120:
                return {
                    "status": "valid",
                    "reason": "Valid numeric age.",
                    "confidence": 0.95
                }
            else:
                return {
                    "status": "invalid",
                    "reason": f"Age '{age_val}' is out of valid human range (0-120).",
                    "confidence": 0.95
                }

    # 9. AMOUNT / CURRENCY VALIDATION
    elif ftype == "amount" or any(k in fname for k in ["amount", "rs", "sum"]):
        if re.search(r"\d", val):
            return {
                "status": "valid",
                "reason": "Valid numerical amount entry.",
                "confidence": 0.90
            }
        else:
            return {
                "status": "invalid",
                "reason": "Amount field must contain numerical figures.",
                "confidence": 0.88
            }

    # 10. SIGNATURE VALIDATION
    elif ftype == "signature" or "sign" in fname:
        if len(val) > 0 and val.lower() not in ["blank", "none", "empty"]:
            return {
                "status": "valid",
                "reason": "Signature ink content detected in box.",
                "confidence": 0.85
            }
        else:
            return {
                "status": "needs_review",
                "reason": "Signature box appears blank or unreadable.",
                "confidence": 0.80
            }

    # DEFAULT FALLBACK
    return {
        "status": "needs_review",
        "reason": f"Format could not be deterministically verified for '{val}'. Please inspect manually.",
        "confidence": 0.65
    }

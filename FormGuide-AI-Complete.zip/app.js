// Global State
let currentAnalysisData = null;
let selectedFieldIndex = -1;
let currentLanguage = 'en';
let currentZoom = 1.0;
let currentMode = 'guidance'; // 'guidance' or 'validation'

// Web Speech Synthesis Engine
const synth = window.speechSynthesis;
let availableVoices = [];

function loadSpeechVoices() {
  if (synth && synth.getVoices) {
    availableVoices = synth.getVoices();
  }
}

if (synth) {
  loadSpeechVoices();
  if (synth.onvoiceschanged !== undefined) {
    synth.onvoiceschanged = loadSpeechVoices;
  }
}

// Page Navigation
const pages = [...document.querySelectorAll('.page')];
const navLinks = [...document.querySelectorAll('nav a')];

function showPage() {
  const hash = location.hash.slice(1) || 'home';
  pages.forEach(page => page.classList.toggle('active', page.id === hash));
  navLinks.forEach(link => {
    const target = link.getAttribute('href').slice(1);
    link.classList.toggle('active', target === hash);
  });

  window.scrollTo(0, 0);

  if (hash === 'dashboard') {
    loadDashboardData();
  }
}

window.addEventListener('hashchange', showPage);
showPage();

// Mode Selector Switcher Cards Handler
const modeGuidanceCard = document.querySelector('#modeGuidanceCard');
const modeValidationCard = document.querySelector('#modeValidationCard');
const dropPromptText = document.querySelector('#dropPromptText');

if (modeGuidanceCard && modeValidationCard) {
  modeGuidanceCard.addEventListener('click', () => {
    currentMode = 'guidance';
    modeGuidanceCard.classList.add('active');
    modeValidationCard.classList.remove('active');
    if (dropPromptText) dropPromptText.textContent = "Choose or drop a blank form file for Guidance Mode";
  });

  modeValidationCard.addEventListener('click', () => {
    currentMode = 'validation';
    modeValidationCard.classList.add('active');
    modeGuidanceCard.classList.remove('active');
    if (dropPromptText) dropPromptText.textContent = "Choose or drop an already-filled form file for Validation Mode";
  });
}

// Load Saved Preferences
async function loadSavedSettings() {
  try {
    const res = await fetch('/api/settings');
    const data = await res.json();
    if (data.success && data.preferences) {
      const p = data.preferences;
      currentLanguage = p.language || 'en';
      document.querySelector('#prefLanguage').value = p.language || 'en';
      document.querySelector('#langSelect').value = p.language || 'en';
      document.querySelector('#prefSpeed').value = String(p.voice_speed || 1.0);
      document.querySelector('#prefVoiceEnabled').value = String(p.voice_enabled !== false);
      document.querySelector('#prefTheme').value = p.theme || 'light';

      if (p.theme === 'dark') {
        document.body.classList.add('dark-theme');
      }
    }
  } catch (err) {
    console.warn("Could not load settings:", err);
  }
}
loadSavedSettings();

// File Upload & Processing
const fileInput = document.querySelector('#file');
const dropZone = document.querySelector('#drop');
const processingCard = document.querySelector('#processingCard');
const progressStepTitle = document.querySelector('#progressStepTitle');
const progressStepDetail = document.querySelector('#progressStepDetail');
const progressBar = document.querySelector('#progressBar');
const previewWrap = document.querySelector('#previewWrap');
const replaceBtn = document.querySelector('#replace');

fileInput.addEventListener('change', event => {
  if (event.target.files.length > 0) {
    handleFileUpload(event.target.files[0]);
  }
});

['dragenter', 'dragover'].forEach(evt => {
  dropZone.addEventListener(evt, e => {
    e.preventDefault();
    dropZone.classList.add('drag');
  });
});

['dragleave', 'drop'].forEach(evt => {
  dropZone.addEventListener(evt, e => {
    e.preventDefault();
    dropZone.classList.remove('drag');
  });
});

dropZone.addEventListener('drop', e => {
  if (e.dataTransfer.files.length > 0) {
    handleFileUpload(e.dataTransfer.files[0]);
  }
});

replaceBtn.addEventListener('click', () => fileInput.click());

async function handleFileUpload(file) {
  if (!file) return;

  const validExts = ['png', 'jpg', 'jpeg', 'pdf'];
  const ext = file.name.rsplit ? file.name.rsplit('.').pop().toLowerCase() : file.name.split('.').pop().toLowerCase();
  
  if (!validExts.includes(ext)) {
    alert("Invalid file format. Please upload a PNG, JPG, JPEG image or PDF document.");
    return;
  }

  // Show processing UI
  dropZone.hidden = true;
  previewWrap.hidden = true;
  processingCard.hidden = false;

  const endpoint = (currentMode === 'validation') ? '/validate-form' : '/analyze';
  const modeLabel = (currentMode === 'validation') ? 'Field Validation' : 'Field Guidance';

  updateProgress(20, `Uploading Form (${modeLabel})...`, "Sending file to server...");

  const formData = new FormData();
  formData.append('file', file);

  try {
    setTimeout(() => updateProgress(45, "Extracting Text...", "Running OpenCV multi-filter preprocessing & Tesseract OCR..."), 600);
    setTimeout(() => updateProgress(70, "Understanding Layout...", "Running FUNSD ML layout classifier & value association..."), 1400);
    setTimeout(() => updateProgress(90, "Running Analysis...", currentMode === 'validation' ? "Applying local privacy validation rules..." : "Generating Gemini AI guidance & translations..."), 2200);

    const response = await fetch(endpoint, {
      method: 'POST',
      body: formData
    });

    const result = await response.json();

    if (!result.success) {
      throw new Error(result.error || "Analysis failed.");
    }

    currentAnalysisData = result;
    updateProgress(100, "Analysis Complete!", "Form processed successfully.");

    setTimeout(() => {
      processingCard.hidden = true;
      document.querySelector('#fileName').textContent = file.name;
      
      const stats = result.statistics || {};
      let summaryStr = `Detected ${stats.fields_detected || 0} fields across ${result.document.pages} page(s).`;
      if (result.mode === 'validation') {
        summaryStr += ` (Valid: ${stats.valid_count || 0}, Invalid: ${stats.invalid_count || 0}, Needs Review: ${stats.needs_review_count || 0})`;
      }
      document.querySelector('#uploadSummaryText').textContent = summaryStr;

      previewWrap.hidden = false;
      document.querySelector('#guidanceNavTab').style.display = 'inline-flex';
    }, 400);

  } catch (err) {
    processingCard.hidden = true;
    dropZone.hidden = false;
    alert(`Error: ${err.message}`);
  }
}

function updateProgress(percent, title, detail) {
  progressBar.style.width = `${percent}%`;
  progressStepTitle.textContent = title;
  progressStepDetail.textContent = detail;
}

document.querySelector('#viewGuidanceBtn').addEventListener('click', () => {
  location.hash = '#guidance';
  renderGuidanceView();
});

// Render Workspace View & Canvas Bounding Boxes
function renderGuidanceView() {
  if (!currentAnalysisData || !currentAnalysisData.fields) return;

  const docImg = document.querySelector('#documentImage');
  const docData = currentAnalysisData.document;
  docImg.src = docData.image_url;

  const isValidation = (currentAnalysisData.mode === 'validation');
  const modeBadge = document.querySelector('#activeModeBadge');
  const legend = document.querySelector('#statusLegend');

  if (modeBadge) {
    modeBadge.textContent = isValidation ? 'FIELD VALIDATION MODE' : 'GUIDANCE MODE';
    modeBadge.style.background = isValidation ? '#27ae60' : 'var(--orange)';
  }

  if (legend) {
    legend.hidden = !isValidation;
  }

  document.querySelector('#guidanceViewContainer').hidden = isValidation;
  document.querySelector('#validationViewContainer').hidden = !isValidation;

  docImg.onload = () => {
    buildOverlayCanvas();
    if (currentAnalysisData.fields.length > 0) {
      selectField(0);
    }
  };
}

function buildOverlayCanvas() {
  const docImg = document.querySelector('#documentImage');
  const overlay = document.querySelector('#overlayCanvas');
  overlay.innerHTML = '';

  const origW = currentAnalysisData.document.width || docImg.naturalWidth;
  const origH = currentAnalysisData.document.height || docImg.naturalHeight;

  const displayW = docImg.clientWidth;
  const displayH = docImg.clientHeight;

  const scaleX = displayW / origW;
  const scaleY = displayH / origH;

  const isValidation = (currentAnalysisData.mode === 'validation');

  currentAnalysisData.fields.forEach((field, index) => {
    const box = document.createElement('div');
    box.className = 'field-box';
    box.dataset.index = index;

    if (isValidation && field.status) {
      box.classList.add(field.status); // 'valid', 'invalid', 'needs_review'
    }

    const boxX = field.x * scaleX;
    const boxY = field.y * scaleY;
    const boxW = Math.max(24, field.width * scaleX);
    const boxH = Math.max(18, field.height * scaleY);

    box.style.left = `${boxX}px`;
    box.style.top = `${boxY}px`;
    box.style.width = `${boxW}px`;
    box.style.height = `${boxH}px`;

    const label = document.createElement('span');
    label.className = 'field-box-label';

    if (isValidation) {
      const statusIcon = field.status === 'valid' ? '✓' : field.status === 'invalid' ? '✗' : '⚠';
      label.textContent = `${statusIcon} #${field.id} ${field.field}`;
    } else {
      label.textContent = `#${field.id} ${field.field}`;
    }

    box.appendChild(label);

    // Interactive Field Click Listener
    box.addEventListener('click', (e) => {
      e.stopPropagation();
      selectField(index);
    });

    overlay.appendChild(box);
  });
}

// Select Field, Highlight Canvas Box & Update Guidance Panel
function selectField(index) {
  if (!currentAnalysisData || !currentAnalysisData.fields[index]) return;

  stopAllSpeech();

  selectedFieldIndex = index;
  const field = currentAnalysisData.fields[index];
  const total = currentAnalysisData.fields.length;

  // Update Active Highlight Box on Image
  const boxes = document.querySelectorAll('.field-box');
  boxes.forEach((box, idx) => {
    const isActive = (idx === index);
    box.classList.toggle('active', isActive);
  });

  // Smooth Scroll Active Box into Container Viewport
  if (boxes[index]) {
    boxes[index].scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
  }

  // Update Field Title & Badges
  document.querySelector('#fieldTypeBadge').textContent = (field.field_type || 'FIELD').toUpperCase();
  document.querySelector('#confidenceTag').textContent = `AI Match: ${Math.round(field.confidence * 100)}%`;

  const lowConfWarning = document.querySelector('#lowConfWarning');
  if (lowConfWarning) lowConfWarning.hidden = !field.is_low_confidence;

  document.querySelector('#fieldCounter').textContent = `${index + 1} / ${total}`;

  updateGuidanceLanguageView();
}

function updateGuidanceLanguageView() {
  if (selectedFieldIndex < 0 || !currentAnalysisData) return;

  const field = currentAnalysisData.fields[selectedFieldIndex];
  const lang = currentLanguage;
  const isValidation = (currentAnalysisData.mode === 'validation');

  // Translated Field Title
  const fieldTitle = (field.translated_field && field.translated_field[lang]) ? field.translated_field[lang] : field.field;
  document.querySelector('#fieldNameTitle').textContent = fieldTitle;

  if (isValidation) {
    const pill = document.querySelector('#valStatusPill');
    const status = field.status || 'needs_review';

    pill.className = `status-pill ${status}`;
    pill.textContent = status === 'valid' ? '✓ VALID' : status === 'invalid' ? '✗ INVALID' : '⚠ NEEDS REVIEW';

    document.querySelector('#valMaskedValue').textContent = field.value_masked || '[Blank / Unfilled]';

    const reasonObj = field.reason || {};
    const reasonText = (reasonObj[lang]) ? reasonObj[lang] : (reasonObj.en || '--');
    document.querySelector('#valReasonText').textContent = reasonText;

  } else {
    const guidanceObj = (field.guidance && field.guidance[lang]) ? field.guidance[lang] : (field.guidance ? field.guidance.en : {});

    document.querySelector('#guidanceMeaning').textContent = guidanceObj.meaning || '--';
    document.querySelector('#guidanceEntry').textContent = guidanceObj.entry || '--';
    document.querySelector('#guidanceExample').textContent = guidanceObj.example || '--';
    document.querySelector('#guidanceTip').textContent = guidanceObj.tip || '--';
    document.querySelector('#guidanceMistake').textContent = guidanceObj.mistake || '--';
  }
}

// Language Selector Change
document.querySelector('#langSelect').addEventListener('change', e => {
  currentLanguage = e.target.value;
  updateGuidanceLanguageView();
  stopAllSpeech();
});

// Navigation Buttons
document.querySelector('#prevFieldBtn').addEventListener('click', () => {
  if (currentAnalysisData && selectedFieldIndex > 0) {
    selectField(selectedFieldIndex - 1);
  }
});

document.querySelector('#nextFieldBtn').addEventListener('click', () => {
  if (currentAnalysisData && selectedFieldIndex < currentAnalysisData.fields.length - 1) {
    selectField(selectedFieldIndex + 1);
  }
});

// Zoom Controls
document.querySelector('#zoomInBtn').addEventListener('click', () => {
  currentZoom = Math.min(2.5, currentZoom + 0.2);
  applyZoom();
});

document.querySelector('#zoomOutBtn').addEventListener('click', () => {
  currentZoom = Math.max(0.6, currentZoom - 0.2);
  applyZoom();
});

document.querySelector('#zoomResetBtn').addEventListener('click', () => {
  currentZoom = 1.0;
  applyZoom();
});

function applyZoom() {
  const canvasWrapper = document.querySelector('#canvasWrapper');
  canvasWrapper.style.transform = `scale(${currentZoom})`;
  document.querySelector('#zoomVal').textContent = `${Math.round(currentZoom * 100)}%`;
}

// Bulletproof Multilingual Voice Guidance Engine (Backend Python MP3 Audio Stream + Web Speech Fallback)
let isCurrentlyPlayingSpeech = false;

function playStartBeep() {
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5 note audio chime
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    }
  } catch (e) {
    console.warn("Audio chime notice:", e);
  }
}

function stopAllSpeech() {
  isCurrentlyPlayingSpeech = false;
  if (synth) {
    try {
      synth.cancel();
      if (synth.resume) synth.resume();
    } catch (e) {
      console.warn("Error resetting speech synth:", e);
    }
  }
  const globalPlayer = document.querySelector('#globalSpeechPlayer');
  if (globalPlayer) {
    globalPlayer.pause();
    globalPlayer.currentTime = 0;
  }
  const speakBtnText = document.querySelector('#speakBtnText');
  if (speakBtnText) speakBtnText.textContent = "Listen Read-Aloud";
}

async function playSpeechText(text, lang) {
  stopAllSpeech();
  isCurrentlyPlayingSpeech = true;
  playStartBeep();

  const speakBtnText = document.querySelector('#speakBtnText');
  if (speakBtnText) speakBtnText.textContent = "Loading Voice...";

  const cleanText = text.replace(/[#*✓✗⚠🔒]/g, '').trim();
  if (!cleanText) {
    stopAllSpeech();
    return;
  }

  const speedSelect = document.querySelector('#prefSpeed');
  const speed = parseFloat(speedSelect ? speedSelect.value : 1.0);

  try {
    const res = await fetch('/api/speak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: cleanText.substring(0, 350), lang: lang })
    });

    if (!res.ok) throw new Error("TTS status " + res.status);

    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);

    const globalPlayer = document.querySelector('#globalSpeechPlayer');
    if (globalPlayer) {
      globalPlayer.pause();
      globalPlayer.src = objectUrl;
      globalPlayer.volume = 1.0;
      globalPlayer.playbackRate = speed;

      globalPlayer.onplaying = () => {
        isCurrentlyPlayingSpeech = true;
        if (speakBtnText) speakBtnText.textContent = "Playing Voice...";
      };

      globalPlayer.onended = () => {
        stopAllSpeech();
        URL.revokeObjectURL(objectUrl);
      };

      globalPlayer.onerror = () => {
        playWebSpeechFallback(cleanText, lang);
      };

      await globalPlayer.play();
      return;
    }
  } catch (err) {
    console.warn("Backend blob TTS notice, falling back to Web Speech:", err);
    playWebSpeechFallback(cleanText, lang);
  }
}

function playWebSpeechFallback(cleanText, lang) {
  if (!synth) {
    const speakBtnText = document.querySelector('#speakBtnText');
    if (speakBtnText) speakBtnText.textContent = "Listen Read-Aloud";
    alert("Audio playback is not supported on this browser.");
    return;
  }

  try {
    synth.cancel();
    if (synth.resume) synth.resume();

    setTimeout(() => {
      // Prevent Chrome garbage collection bug by binding to window object
      window.currentUtterance = new SpeechSynthesisUtterance(cleanText);
      const utterance = window.currentUtterance;
      
      let targetLangCode = 'en-IN';
      if (lang === 'te') targetLangCode = 'te-IN';
      if (lang === 'hi') targetLangCode = 'hi-IN';

      utterance.lang = targetLangCode;
      utterance.volume = 1.0;

      const availableVoices = synth.getVoices ? synth.getVoices() : [];
      let matchedVoice = availableVoices.find(v => 
        v.lang === targetLangCode || 
        v.lang.toLowerCase().includes(lang) ||
        v.name.toLowerCase().includes(lang === 'te' ? 'telugu' : lang === 'hi' ? 'hindi' : 'english')
      );

      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      const speedSelect = document.querySelector('#prefSpeed');
      utterance.rate = parseFloat(speedSelect ? speedSelect.value : 1.0);

      const speakBtnText = document.querySelector('#speakBtnText');

      utterance.onstart = () => {
        if (speakBtnText) speakBtnText.textContent = "Playing Voice...";
      };

      utterance.onend = () => {
        if (speakBtnText) speakBtnText.textContent = "Listen Read-Aloud";
        window.currentUtterance = null;
      };

      utterance.onerror = (e) => {
        console.warn("Web speech fallback error:", e);
        if (speakBtnText) speakBtnText.textContent = "Listen Read-Aloud";
        window.currentUtterance = null;
      };

      synth.speak(utterance);
    }, 50);

  } catch (err) {
    console.error("Web speech fallback exception:", err);
    const speakBtnText = document.querySelector('#speakBtnText');
    if (speakBtnText) speakBtnText.textContent = "Listen Read-Aloud";
  }
}

document.querySelector('#speakBtn').addEventListener('click', () => {
  if (!currentAnalysisData || !currentAnalysisData.fields || currentAnalysisData.fields.length === 0) {
    alert("Please upload and analyze a form before listening to voice guidance.");
    return;
  }

  // Auto select first field if none selected
  if (selectedFieldIndex < 0) {
    selectField(0);
  }

  if (isCurrentlyPlayingSpeech) {
    stopAllSpeech();
    return;
  }

  const field = currentAnalysisData.fields[selectedFieldIndex];
  const lang = currentLanguage;
  const isValidation = (currentAnalysisData.mode === 'validation');

  let speechText = '';
  if (isValidation) {
    const statusStr = field.status === 'valid' ? (lang === 'te' ? 'సరిగ్గా ఉంది' : lang === 'hi' ? 'सही है' : 'is valid') : 
                      field.status === 'invalid' ? (lang === 'te' ? 'తప్పుగా ఉంది' : lang === 'hi' ? 'गलत है' : 'is invalid') : 
                      (lang === 'te' ? 'పరిశీలన అవసరం' : lang === 'hi' ? 'समीक्षा आवश्यक' : 'needs review');
    const reasonText = (field.reason && field.reason[lang]) ? field.reason[lang] : (field.reason ? field.reason.en : '');
    speechText = `${field.field}: ${statusStr}. ${reasonText}`;
  } else {
    const g = (field.guidance && field.guidance[lang]) ? field.guidance[lang] : (field.guidance ? field.guidance.en : {});
    const fieldTitle = (field.translated_field && field.translated_field[lang]) ? field.translated_field[lang] : field.field;
    speechText = `${fieldTitle}. ${g.meaning || ''}. ${g.entry || ''}. ${g.example ? 'Example: ' + g.example : ''}`;
  }

  playSpeechText(speechText, lang);
});

// Dashboard Data Fetcher
async function loadDashboardData() {
  try {
    const statsRes = await fetch('/api/stats');
    const statsData = await statsRes.json();
    if (statsData.success) {
      document.querySelector('#statFormsCount').textContent = statsData.stats.forms_analyzed;
      document.querySelector('#statFieldsCount').textContent = statsData.stats.fields_detected;
    }

    const histRes = await fetch('/api/history');
    const histData = await histRes.json();
    const tbody = document.querySelector('#historyTableBody');

    if (histData.success && histData.history.length > 0) {
      tbody.innerHTML = histData.history.map(row => `
        <tr>
          <td>#${row.id}</td>
          <td><strong>${row.original_name}</strong></td>
          <td>${row.page_count}</td>
          <td>${row.fields_count} fields</td>
          <td>${row.created_at}</td>
        </tr>
      `).join('');
    } else {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--muted);">No forms analyzed yet in this session.</td></tr>`;
    }
  } catch (err) {
    console.error("Failed to load dashboard data:", err);
  }
}

// Settings Form Submission
document.querySelector('#settingsForm').addEventListener('submit', async e => {
  e.preventDefault();

  const lang = document.querySelector('#prefLanguage').value;
  const voiceEnabled = document.querySelector('#prefVoiceEnabled').value === 'true';
  const speed = parseFloat(document.querySelector('#prefSpeed').value);
  const theme = document.querySelector('#prefTheme').value;

  try {
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        language: lang,
        voice_enabled: voiceEnabled,
        voice_speed: speed,
        theme: theme
      })
    });

    const data = await res.json();
    if (data.success) {
      currentLanguage = lang;
      document.querySelector('#langSelect').value = lang;
      document.body.classList.toggle('dark-theme', theme === 'dark');

      const msg = document.querySelector('#savedMessage');
      msg.textContent = "Preferences saved successfully!";
      setTimeout(() => msg.textContent = '', 3000);
    }
  } catch (err) {
    alert(`Failed to save settings: ${err.message}`);
  }
});

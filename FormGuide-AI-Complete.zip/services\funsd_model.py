import os
import joblib
import logging
import numpy as np
import config
from services.document_understanding import extract_block_features
from ml.funsd_dataset import extract_features_from_annotation
from ml.train_funsd import train_and_evaluate_funsd_model

logger = logging.getLogger(__name__)

class FUNSDClassifier:
    def __init__(self, model_path=config.MODEL_PATH):
        self.model_path = model_path
        self.model = None
        self.classes = []
        self.metrics = {}
        self._load_or_train_model()

    def _load_or_train_model(self):
        if os.path.exists(self.model_path):
            try:
                saved_data = joblib.load(self.model_path)
                self.model = saved_data.get("model")
                self.classes = saved_data.get("classes", [])
                self.metrics = saved_data.get("metrics", {})
                logger.info(f"Loaded FUNSD model from {self.model_path}")
                return
            except Exception as e:
                logger.warning(f"Failed loading model at {self.model_path} ({e}). Retraining...")

        # Train model if not existing
        try:
            self.model, self.metrics = train_and_evaluate_funsd_model(str(self.model_path))
            self.classes = list(self.model.classes_)
        except Exception as e:
            logger.error(f"Error initializing FUNSD model: {e}")

    def predict_label(self, block, page_width, page_height):
        """
        Predicts FUNSD label ('question', 'answer', 'header', 'other') for a text block.
        Returns label string and confidence score.
        """
        if not self.model:
            # Heuristic fallback if model unavailable
            text = block.get("text", "")
            if ":" in text or any(kw in text.lower() for kw in ["name", "date", "address", "number"]):
                return "question", 0.75
            elif text.isupper() and len(text) > 3:
                return "header", 0.70
            else:
                return "other", 0.60

        features = extract_features_from_annotation(
            {"text": block.get("text", ""), "box": [
                block.get("x", 0), block.get("y", 0),
                block.get("x", 0) + block.get("width", 10),
                block.get("y", 0) + block.get("height", 10)
            ]},
            page_w=page_width,
            page_h=page_height
        )

        probs = self.model.predict_proba([features])[0]
        max_idx = np.argmax(probs)
        label = str(self.classes[max_idx])
        conf = float(probs[max_idx])

        return label, conf

funsd_classifier = FUNSDClassifier()

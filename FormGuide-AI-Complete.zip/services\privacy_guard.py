import os
import re
import logging

logger = logging.getLogger(__name__)

def mask_sensitive_value(value, field_type="general"):
    """
    Masks sensitive personal information for UI display.
    Examples:
    - Phone: 9876543210 -> XXXXXX3210
    - Account Number: 123456789012 -> XXXXXXXX9012
    - Email: john.smith@example.com -> j***@example.com
    - Aadhaar / PAN / ID: XXXXXXXX1234
    """
    if not value or not isinstance(value, str):
        return ""

    val = value.strip()
    if len(val) == 0:
        return ""

    field_type_clean = (field_type or "general").lower()

    if field_type_clean in ["phone", "mobile", "contact"]:
        digits = re.sub(r"\D", "", val)
        if len(digits) >= 10:
            return "X" * (len(digits) - 4) + digits[-4:]
        elif len(digits) > 4:
            return "X" * (len(digits) - 2) + digits[-2:]

    elif field_type_clean in ["account_number", "acc_no", "bank_account", "pan", "aadhaar", "id"]:
        digits_or_chars = re.sub(r"\s", "", val)
        if len(digits_or_chars) >= 8:
            return "X" * (len(digits_or_chars) - 4) + digits_or_chars[-4:]
        elif len(digits_or_chars) > 4:
            return "X" * (len(digits_or_chars) - 2) + digits_or_chars[-2:]

    elif field_type_clean == "email":
        if "@" in val:
            parts = val.split("@", 1)
            name_part = parts[0]
            domain_part = parts[1]
            if len(name_part) > 2:
                masked_name = name_part[0] + "***" + name_part[-1]
            else:
                masked_name = name_part[0] + "***"
            return f"{masked_name}@{domain_part}"

    elif field_type_clean == "signature":
        return "[Signature Ink Marks Detected]"

    # Default general masking for strings longer than 12 chars
    if len(val) > 12:
        return val[:3] + "..." + val[-3:]

    return val

def redact_for_logging(text):
    """
    Redacts sensitive phone numbers, account numbers, and emails from log strings.
    Replaces matches with [REDACTED].
    """
    if not text or not isinstance(text, str):
        return ""

    # Redact 10+ digit numbers
    redacted = re.sub(r"\b\d{10,16}\b", "[REDACTED_NUMBER]", text)
    # Redact email addresses
    redacted = re.sub(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "[REDACTED_EMAIL]", redacted)
    
    return redacted

def cleanup_temp_file(file_path):
    """
    Securely deletes temporary uploaded form image/PDF file after processing.
    """
    if not file_path:
        return

    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            logger.info(f"Cleaned up temporary uploaded file: {file_path}")
    except Exception as e:
        logger.warning(f"Could not remove temp file {file_path}: {e}")

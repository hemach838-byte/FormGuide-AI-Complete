import logging
from services.gemini_service import generate_gemini_guidance

logger = logging.getLogger(__name__)

# Fallback Guidance Templates by Field Type
TEMPLATE_GUIDANCE = {
    "name": {
        "meaning": "This field asks for your official full name.",
        "entry": "Write your complete legal name exactly as printed on your government identity card (e.g. Aadhaar or PAN).",
        "example": "John Smith",
        "tip": "Use CAPITAL letters if the form specifies block letters.",
        "mistake": "Do not use short nicknames or initials unless specified."
    },
    "date": {
        "meaning": "This field asks for a specific calendar date.",
        "entry": "Write the date in DD/MM/YYYY format using numbers.",
        "example": "15/08/1995",
        "tip": "Double check the month and year before writing.",
        "mistake": "Avoid writing month names in words if boxes are provided."
    },
    "dob": {
        "meaning": "This field asks for your Date of Birth.",
        "entry": "Enter your official date of birth as registered in official records.",
        "example": "01/01/1990",
        "tip": "Ensure the date matches your birth certificate or identity card.",
        "mistake": "Do not enter today's date by mistake."
    },
    "phone": {
        "meaning": "This field asks for your active mobile phone number.",
        "entry": "Enter your 10-digit mobile number.",
        "example": "9876543210",
        "tip": "Provide a phone number that is currently active to receive OTP updates.",
        "mistake": "Do not add country code (+91) unless specifically asked."
    },
    "email": {
        "meaning": "This field asks for your electronic email address.",
        "entry": "Enter your full email address including the domain.",
        "example": "user@example.com",
        "tip": "Write clearly in lowercase letters.",
        "mistake": "Do not leave out the @ symbol or domain name (.com)."
    },
    "account_number": {
        "meaning": "This field asks for your bank account number.",
        "entry": "Enter your complete bank account number carefully digit by digit.",
        "example": "123456789012",
        "tip": "Verify each digit with your bank passbook or cheque book.",
        "mistake": "Mistaking '0' (zero) for 'O' (letter O)."
    },
    "ifsc": {
        "meaning": "This field asks for the 11-character Indian Financial System Code of your bank branch.",
        "entry": "Enter the 11-character alphanumeric IFSC code found on your passbook.",
        "example": "SBIN0001234",
        "tip": "The 5th character is always the number zero (0).",
        "mistake": "Confusing the letter 'O' with number '0'."
    },
    "amount": {
        "meaning": "This field asks for a financial amount in currency.",
        "entry": "Write the total numerical amount clearly in figures or words as requested.",
        "example": "Rs. 5,000/- (Rupees Five Thousand Only)",
        "tip": "Write '/-' after figures to prevent unauthorized modifications.",
        "mistake": "Writing incorrect number of zeroes."
    },
    "address": {
        "meaning": "This field asks for your current or permanent residential address.",
        "entry": "Write house number, street name, locality, city, state, and 6-digit PIN code.",
        "example": "Door No 12-3, Main Road, Hyderabad, Telangana - 500001",
        "tip": "Always include your 6-digit postal PIN code.",
        "mistake": "Leaving out town or PIN code."
    },
    "signature": {
        "meaning": "This area is reserved for your official handwritten signature.",
        "entry": "Sign inside the specified box using a blue or black ballpoint pen.",
        "example": "[Your Usual Handwritten Signature]",
        "tip": "Keep your signature entirely inside the designated boundary lines.",
        "mistake": "Never let your signature cross over into other text boxes."
    },
    "yes_no": {
        "meaning": "This field requires selecting one choice option.",
        "entry": "Put a check mark (✓) or cross (✗) inside the single box that applies to you.",
        "example": "[✓] Yes",
        "tip": "Select only one option unless multi-selection is permitted.",
        "mistake": "Checking multiple conflicting options."
    },
    "account_type": {
        "meaning": "This field asks for the type of bank account you wish to open or manage (e.g., Savings, Current, or Salary account).",
        "entry": "Select or tick one option such as Savings Account, Current Account, or Salary Account.",
        "example": "Savings Account",
        "tip": "Ensure you pick the account type that matches your banking needs.",
        "mistake": "Selecting multiple conflicting account types."
    },
    "general": {
        "meaning": "This field requires specific information indicated by its label prompt.",
        "entry": "Enter clear, accurate information as requested by the document label.",
        "example": "Sample answer",
        "tip": "Write legibly and keep text within the box boundaries.",
        "mistake": "Writing outside the provided lines."
    }
}

def generate_field_guidance(field_name, field_type="general", context=""):
    """
    Generates guidance using Google Gemini API first, falling back to template engine.
    """
    # 1. Attempt Gemini AI guidance
    ai_guidance = generate_gemini_guidance(field_name, field_type, context)
    if ai_guidance:
        return ai_guidance

    # 2. Template Fallback
    template = TEMPLATE_GUIDANCE.get(field_type, TEMPLATE_GUIDANCE["general"]).copy()

    if field_name:
        clean_name = field_name.strip()
        template["meaning"] = template["meaning"].replace("This field", f"This field ('{clean_name}')")
        if field_type == "general":
            template["entry"] = f"Write clear, accurate information corresponding to {clean_name}."

    return template

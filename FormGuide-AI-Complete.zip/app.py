import os
import uuid
import logging
from flask import Flask, request, jsonify, send_from_directory, Response
from werkzeug.utils import secure_filename

import config
from database import db
from services.pdf_converter import convert_pdf_to_images
from services.ocr_engine import run_ocr
from services.qa_association import associate_questions_and_answers
from services.guidance_engine import generate_field_guidance
from services.translation_service import translate_guidance_dict, translate_text

from services.privacy_guard import mask_sensitive_value, redact_for_logging, cleanup_temp_file
from services.validation_engine import validate_field_entry
from services.tts_service import generate_speech_audio

# Configure Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder=".", static_url_path="")
app.config['UPLOAD_FOLDER'] = str(config.UPLOAD_FOLDER)
app.config['MAX_CONTENT_LENGTH'] = config.MAX_CONTENT_LENGTH

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in config.ALLOWED_EXTENSIONS

@app.route("/")
def serve_index():
    return send_from_directory(".", "index.html")

@app.route("/uploads/<path:filename>")
def serve_upload(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route("/health", methods=["GET"])
def health_check():
    stats = db.get_stats()
    return jsonify({
        "status": "healthy",
        "tesseract_cmd": config.TESSERACT_CMD,
        "tesseract_exists": os.path.exists(config.TESSERACT_CMD),
        "database": stats.get("database"),
        "gemini_api_configured": bool(config.GEMINI_API_KEY)
    })

@app.route("/analyze", methods=["POST"])
def analyze_form():
    if 'file' not in request.files:
        return jsonify({"success": False, "error": "No file uploaded."}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"success": False, "error": "No file selected."}), 400

    if not allowed_file(file.filename):
        return jsonify({"success": False, "error": "Invalid file format. Allowed: PNG, JPG, JPEG, PDF"}), 400

    try:
        orig_filename = secure_filename(file.filename)
        ext = orig_filename.rsplit('.', 1)[1].lower()
        unique_name = f"{uuid.uuid4().hex[:10]}_{orig_filename}"
        saved_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_name)
        file.save(saved_path)

        page_images = []
        if ext == 'pdf':
            pdf_pages = convert_pdf_to_images(saved_path, app.config['UPLOAD_FOLDER'])
            page_images = pdf_pages
        else:
            page_images = [{
                "page_num": 1,
                "image_name": unique_name,
                "image_path": saved_path,
                "width": 0,
                "height": 0
            }]

        all_fields = []
        primary_image_url = f"/uploads/{page_images[0]['image_name']}"
        primary_w = 0
        primary_h = 0

        # Process first page primarily for OCR and field detection
        page_one = page_images[0]
        ocr_res = run_ocr(page_one['image_path'])
        primary_w = ocr_res['width']
        primary_h = ocr_res['height']

        # Detect fields and Q&A association
        detected = associate_questions_and_answers(ocr_res)

        # Generate structured guidance & multilingual translations for each field
        for f in detected:
            guidance_en = generate_field_guidance(f['field'], f['field_type'])
            guidance_te = translate_guidance_dict(guidance_en, 'te')
            guidance_hi = translate_guidance_dict(guidance_en, 'hi')

            f['guidance'] = {
                "en": guidance_en,
                "te": guidance_te,
                "hi": guidance_hi
            }
            f['translated_field'] = {
                "en": f['field'],
                "te": translate_text(f['field'], 'te'),
                "hi": translate_text(f['field'], 'hi')
            }
            all_fields.append(f)

        # Save session to Database
        db.save_analysis(unique_name, orig_filename, len(page_images), all_fields)

        return jsonify({
            "success": True,
            "mode": "guidance",
            "document": {
                "filename": unique_name,
                "original_filename": orig_filename,
                "image_url": primary_image_url,
                "pages": len(page_images),
                "width": primary_w,
                "height": primary_h
            },
            "statistics": {
                "fields_detected": len(all_fields)
            },
            "fields": all_fields
        })

    except Exception as e:
        logger.error(f"Form guidance processing failed: {e}", exc_info=True)
        return jsonify({"success": False, "error": f"Form processing error: {str(e)}"}), 500

@app.route("/validate-form", methods=["POST"])
def validate_form():
    if 'file' not in request.files:
        return jsonify({"success": False, "error": "No file uploaded."}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"success": False, "error": "No file selected."}), 400

    if not allowed_file(file.filename):
        return jsonify({"success": False, "error": "Invalid file format. Allowed: PNG, JPG, JPEG, PDF"}), 400

    try:
        orig_filename = secure_filename(file.filename)
        ext = orig_filename.rsplit('.', 1)[1].lower()
        unique_name = f"{uuid.uuid4().hex[:10]}_{orig_filename}"
        saved_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_name)
        file.save(saved_path)

        page_images = []
        if ext == 'pdf':
            pdf_pages = convert_pdf_to_images(saved_path, app.config['UPLOAD_FOLDER'])
            page_images = pdf_pages
        else:
            page_images = [{
                "page_num": 1,
                "image_name": unique_name,
                "image_path": saved_path,
                "width": 0,
                "height": 0
            }]

        page_one = page_images[0]
        ocr_res = run_ocr(page_one['image_path'])
        primary_w = ocr_res['width']
        primary_h = ocr_res['height']

        detected = associate_questions_and_answers(ocr_res)
        validated_fields = []

        valid_cnt = 0
        invalid_cnt = 0
        review_cnt = 0

        for f in detected:
            raw_val = f.get('value', '')
            field_name = f.get('field', '')
            field_type = f.get('field_type', 'general')

            # Run Local Privacy Guard Masking
            masked_val = mask_sensitive_value(raw_val, field_type)

            # Run Local Format Validation Engine
            val_res = validate_field_entry(field_name, raw_val, field_type, is_required=True)
            status = val_res.get('status', 'needs_review')
            reason_en = val_res.get('reason', '')

            if status == 'valid':
                valid_cnt += 1
            elif status == 'invalid':
                invalid_cnt += 1
            else:
                review_cnt += 1

            # Translate ONLY the generic explanation string, NEVER sensitive user values
            reason_te = translate_text(reason_en, 'te')
            reason_hi = translate_text(reason_en, 'hi')

            validated_fields.append({
                "id": f['id'],
                "field": field_name,
                "field_type": field_type,
                "value_masked": masked_val if masked_val else "[Blank / Unfilled]",
                "status": status,
                "reason": {
                    "en": reason_en,
                    "te": reason_te,
                    "hi": reason_hi
                },
                "confidence": min(f.get('confidence', 0.8), val_res.get('confidence', 0.8)),
                "x": f['x'],
                "y": f['y'],
                "width": f['width'],
                "height": f['height']
            })

            # Log privacy redaction
            logger.info(f"Validated Field '{field_name}' -> Status: {status} (Value: [REDACTED])")

        # Save privacy-preserved metadata to Database
        db.save_analysis(unique_name, orig_filename, len(page_images), validated_fields)

        return jsonify({
            "success": True,
            "mode": "validation",
            "document": {
                "filename": unique_name,
                "original_filename": orig_filename,
                "image_url": f"/uploads/{page_images[0]['image_name']}",
                "pages": len(page_images),
                "width": primary_w,
                "height": primary_h
            },
            "statistics": {
                "fields_detected": len(validated_fields),
                "valid_count": valid_cnt,
                "invalid_count": invalid_cnt,
                "needs_review_count": review_cnt
            },
            "fields": validated_fields
        })

    except Exception as e:
        logger.error(f"Form validation processing failed: {e}", exc_info=True)
        return jsonify({"success": False, "error": f"Form validation error: {str(e)}"}), 500

@app.route("/api/history", methods=["GET"])
def get_history():
    history_records = db.get_history(limit=20)
    return jsonify({"success": True, "history": history_records})

@app.route("/api/stats", methods=["GET"])
def get_stats():
    stats = db.get_stats()
    return jsonify({"success": True, "stats": stats})

@app.route("/api/settings", methods=["GET", "POST"])
def user_settings():
    if request.method == "POST":
        data = request.json or {}
        lang = data.get("language", "en")
        speed = float(data.get("voice_speed", 1.0))
        voice_enabled = bool(data.get("voice_enabled", True))
        theme = data.get("theme", "light")

        saved = db.save_preferences(lang, speed, voice_enabled, theme)
        return jsonify({"success": saved})
    else:
        prefs = db.get_preferences()
        return jsonify({"success": True, "preferences": prefs})

@app.route("/api/translate_field", methods=["POST"])
def translate_field_endpoint():
    data = request.json or {}
    guidance = data.get("guidance", {})
    target_lang = data.get("language", "en")

    translated = translate_guidance_dict(guidance, target_lang)
    return jsonify({"success": True, "guidance": translated})

@app.route("/api/speak", methods=["GET", "POST"])
def speak_tts():
    if request.method == "POST":
        data = request.json or {}
        text = data.get("text", "")
        lang = data.get("lang", "en")
    else:
        text = request.args.get("text", "")
        lang = request.args.get("lang", "en")

    audio_bytes, mimetype = generate_speech_audio(text, lang)
    if audio_bytes:
        return Response(audio_bytes, mimetype=mimetype)
    else:
        return jsonify({"success": False, "error": "Speech generation failed"}), 400

if __name__ == "__main__":
    print("Starting FormGuide AI Flask Server on http://localhost:5000 ...")
    app.run(host="0.0.0.0", port=5000, debug=True)

import time
import logging
from deep_translator import GoogleTranslator

logger = logging.getLogger(__name__)

# Pre-cached Common Translations for high performance
PRECACHED_TRANSLATIONS = {
    "te": {
        "Full Name": "పూర్తి పేరు",
        "Date of Birth": "పుట్టిన తేదీ",
        "Mobile Number": "మొబైల్ నంబర్",
        "Account Type": "ఖాతా రకం",
        "Address": "చిరునామా",
        "Signature": "సంతకం",
        "This field asks for your official full name.": "ఈ ఫీల్డ్ మీ అధికారిక పూర్తి పేరును అడుగుతుంది.",
        "Write your complete legal name exactly as printed on your government identity card (e.g. Aadhaar or PAN).": "మీ ప్రభుత్వ గుర్తింపు కార్డు పై ఉన్న విధంగా మీ పూర్తి చట్టబద్ధమైన పేరును రాయండి.",
        "John Smith": "జాన్ స్మిత్",
        "Use CAPITAL letters if the form specifies block letters.": "ఫారమ్ బ్లాక్ లెటర్స్ పేర్కొంటే క్యాపిటల్ అక్షరాలను ఉపయోగించండి.",
        "Do not use short nicknames or initials unless specified.": "పేర్కొనకపోతే చిన్న అలియాస్ పేరు లేదా పొడిక్షరాలను ఉపయోగించవద్దు."
    },
    "hi": {
        "Full Name": "पूरा नाम",
        "Date of Birth": "जन्म तिथि",
        "Mobile Number": "मोबाइल नंबर",
        "Account Type": "खाता प्रकार",
        "Address": "पता",
        "Signature": "हस्ताक्षर",
        "This field asks for your official full name.": "यह फ़ील्ड आपके आधिकारिक पूरे नाम की मांग करता है।",
        "Write your complete legal name exactly as printed on your government identity card (e.g. Aadhaar or PAN).": "अपने सरकारी पहचान पत्र पर छपे अनुसार अपना पूरा नाम लिखें।",
        "John Smith": "जॉन स्मिथ",
        "Use CAPITAL letters if the form specifies block letters.": "यदि फॉर्म ब्लॉक अक्षरों को निर्दिष्ट करता है तो बड़े अक्षरों का उपयोग करें।",
        "Do not use short nicknames or initials unless specified.": "जब तक निर्दिष्ट न हो छोटे उपनाम या आद्याक्षर का उपयोग न करें।"
    }
}

# Rate Limit Cooldown State
LAST_RATE_LIMIT_TIME = 0
COOLDOWN_SECONDS = 30

TRANSLATION_CACHE = {}

def translate_text(text, target_lang='en'):
    """
    Translates a single string into target language ('en', 'te', 'hi').
    Uses in-memory cache and pre-cached mappings with automatic rate-limit cooldown.
    """
    global LAST_RATE_LIMIT_TIME
    if not text or target_lang == 'en':
        return text

    cache_key = f"{target_lang}:{text}"
    if cache_key in TRANSLATION_CACHE:
        return TRANSLATION_CACHE[cache_key]

    if target_lang in PRECACHED_TRANSLATIONS and text in PRECACHED_TRANSLATIONS[target_lang]:
        return PRECACHED_TRANSLATIONS[target_lang][text]

    # If in rate-limit cooldown period, return original text immediately to avoid lag
    if time.time() - LAST_RATE_LIMIT_TIME < COOLDOWN_SECONDS:
        return text

    try:
        translated = GoogleTranslator(source='auto', target=target_lang).translate(text)
        if translated:
            TRANSLATION_CACHE[cache_key] = translated
            return translated
    except Exception as e:
        LAST_RATE_LIMIT_TIME = time.time()
        logger.warning(f"Translation rate-limit encountered. Activating {COOLDOWN_SECONDS}s fallback cooldown.")

    return text  # Return original English text on fallback

def translate_guidance_dict(guidance_dict, target_lang='en'):
    """
    Translates all 5 fields of a guidance dictionary (meaning, entry, example, tip, mistake).
    """
    if not guidance_dict or target_lang == 'en':
        return guidance_dict

    translated_guidance = {}
    for key in ["meaning", "entry", "example", "tip", "mistake"]:
        original_text = guidance_dict.get(key, "")
        translated_guidance[key] = translate_text(original_text, target_lang)

    return translated_guidance
